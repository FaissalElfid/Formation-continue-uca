#
# TABLE STRUCTURE FOR: attachments
#

DROP TABLE IF EXISTS `attachments`;

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `uploader_id` varchar(20) NOT NULL,
  `class_id` varchar(20) DEFAULT 'unfiltered',
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `session_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `attachments` (`id`, `title`, `remarks`, `uploader_id`, `class_id`, `file_name`, `enc_name`, `session_id`, `date`, `branch_id`, `created_at`, `updated_at`) VALUES (12, 'Finance', '', '2', '2', 'Finance_,_Banque_et_Assurance_mode_hybrid.pdf', '54601b04a21780196e8035337950b476.pdf', 3, '2021-12-10', 1, '2021-12-10 18:17:28', '2021-12-10 18:17:28');


#
# TABLE STRUCTURE FOR: branch
#

DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `school_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `symbol` varchar(25) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `stu_generate` tinyint(3) DEFAULT '0',
  `stu_username_prefix` varchar(255) NOT NULL,
  `stu_default_password` varchar(255) NOT NULL,
  `grd_generate` tinyint(3) DEFAULT '0',
  `grd_username_prefix` varchar(255) NOT NULL,
  `grd_default_password` varchar(255) NOT NULL,
  `teacher_restricted` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `branch` (`id`, `name`, `school_name`, `email`, `mobileno`, `currency`, `symbol`, `city`, `state`, `address`, `stu_generate`, `stu_username_prefix`, `stu_default_password`, `grd_generate`, `grd_username_prefix`, `grd_default_password`, `teacher_restricted`, `created_at`, `updated_at`) VALUES (1, 'UCA', 'UCA', 'faissal.elfid@gmail.com', '0682484660', 'MAD', 'MAD', 'Marrakech', '', 'FSTG, marrakech', 0, '', '', 0, '', '', 1, '2021-11-04 20:15:46', NULL);


#
# TABLE STRUCTURE FOR: class
#

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_numeric` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (1, 'Licence', '2', '2021-11-07 15:40:43', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (2, 'Master', '', '2021-11-09 20:03:27', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (3, 'FORMATIONS QUALIFIANTES ET CERTIFIANTES', '', '2021-11-09 20:03:47', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (4, 'DIPLÔME UNIVERSITAIRE MÉDECINE', '', '2021-11-09 20:04:04', NULL, 1);


#
# TABLE STRUCTURE FOR: custom_field
#

DROP TABLE IF EXISTS `custom_field`;

CREATE TABLE `custom_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_to` varchar(50) DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text,
  `field_type` enum('text','textarea','dropdown','date','checkbox','number','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `show_on_table` varchar(5) DEFAULT NULL,
  `field_order` int(11) NOT NULL,
  `bs_column` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `custom_field` (`id`, `form_to`, `field_label`, `default_value`, `field_type`, `required`, `status`, `show_on_table`, `field_order`, `bs_column`, `branch_id`, `created_at`) VALUES (1, 'online_admission', 'Nationalité', '', 'text', '1', 1, '1', 2, 6, 1, '2021-11-09 18:24:33');
INSERT INTO `custom_field` (`id`, `form_to`, `field_label`, `default_value`, `field_type`, `required`, `status`, `show_on_table`, `field_order`, `bs_column`, `branch_id`, `created_at`) VALUES (2, 'online_admission', 'Code Postale', '', 'number', '1', 1, '1', 1, 6, 1, '2021-11-09 18:26:23');
INSERT INTO `custom_field` (`id`, `form_to`, `field_label`, `default_value`, `field_type`, `required`, `status`, `show_on_table`, `field_order`, `bs_column`, `branch_id`, `created_at`) VALUES (3, 'online_admission', 'CIN/Passport', '', 'text', '1', 1, '1', 3, 12, 1, '2021-11-09 20:29:11');
INSERT INTO `custom_field` (`id`, `form_to`, `field_label`, `default_value`, `field_type`, `required`, `status`, `show_on_table`, `field_order`, `bs_column`, `branch_id`, `created_at`) VALUES (4, 'online_admission', 'Situation Familiale', 'Fonctionnaire,Salarié(e),Retraité(e),Sans Emploi', 'dropdown', '1', 1, '1', 4, 6, 1, '2021-11-09 20:31:26');
INSERT INTO `custom_field` (`id`, `form_to`, `field_label`, `default_value`, `field_type`, `required`, `status`, `show_on_table`, `field_order`, `bs_column`, `branch_id`, `created_at`) VALUES (5, 'online_admission', 'Domaine d\'Activité', 'Agroalimentaire,Banque / Assurance,BTP / Matériaux de construction,Tourisme', 'dropdown', '1', 1, '1', 5, 6, 1, '2021-11-09 20:33:19');


#
# TABLE STRUCTURE FOR: custom_fields_values
#

DROP TABLE IF EXISTS `custom_fields_values`;

CREATE TABLE `custom_fields_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `custom_fields_values` (`id`, `relid`, `field_id`, `value`) VALUES (1, 2, 2, '30000');
INSERT INTO `custom_fields_values` (`id`, `relid`, `field_id`, `value`) VALUES (2, 2, 1, 'Marrocain');
INSERT INTO `custom_fields_values` (`id`, `relid`, `field_id`, `value`) VALUES (3, 2, 3, 'Z235468');
INSERT INTO `custom_fields_values` (`id`, `relid`, `field_id`, `value`) VALUES (4, 2, 4, 'salari_e');
INSERT INTO `custom_fields_values` (`id`, `relid`, `field_id`, `value`) VALUES (5, 2, 5, 'agroalimentaire');


#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_user` varchar(255) DEFAULT NULL,
  `smtp_pass` varchar(255) DEFAULT NULL,
  `smtp_port` varchar(100) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (1, 'account_registered', '{institute_name}, {name}, {login_username}, {password}, {user_role}, {login_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (2, 'forgot_password', '{institute_name}, {username}, {email}, {reset_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (3, 'change_password', '{institute_name}, {name}, {email}, {password}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (4, 'new_message_received', '{institute_name}, {recipient}, {message}, {message_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (5, 'payslip_generated', '{institute_name}, {username}, {month_year}, {payslip_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (6, 'award', '{institute_name}, {winner_name}, {award_name}, {gift_item}, {award_reason}, {given_date}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (7, 'leave_approve', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (8, 'leave_reject', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (9, 'advance_salary_approve', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (10, 'advance_salary_reject', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (11, 'apply_online_admission', '{institute_name}, {admission_id}, {applicant_name}, {applicant_mobile}, {class}, {section}, {apply_date}, {payment_url}, {admission_copy_url}, {paid_amount}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (12, 'student_admission', '{institute_name}, {academic_year}, {admission_date}, {admission_no}, {roll}, {category}, {student_name}, {student_mobile}, {class}, {section}, {login_username}, {password}, {login_url}');


#
# TABLE STRUCTURE FOR: email_templates_details
#

DROP TABLE IF EXISTS `email_templates_details`;

CREATE TABLE `email_templates_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_body` text NOT NULL,
  `notified` tinyint(1) NOT NULL DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: enroll
#

DROP TABLE IF EXISTS `enroll`;

CREATE TABLE `enroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `roll` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` tinyint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: front_cms_about
#

DROP TABLE IF EXISTS `front_cms_about`;

CREATE TABLE `front_cms_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `about_image` varchar(255) NOT NULL,
  `elements` mediumtext NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_about` (`id`, `title`, `subtitle`, `page_title`, `content`, `banner_image`, `about_image`, `elements`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Guide', 'Le candidat doit choisir une formation, et suivre les indications suivantes :', 'About Us', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut volutpat rutrum eros amet sollicitudin interdum. Suspendisse pulvinar, velit nec pharetra interdum, ante tellus ornare mi, et mollis tellus neque vitae elit. Mauris adipiscing mauris fringilla turpis interdum sed pulvinar nisi malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\r\n                        </p>\r\n                        <p>\r\n                            Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Duis mollis, est non commodo luctus, nisi erat porttitor ligula. Mauris sit amet neque nec nunc gravida. \r\n                        </p>\r\n                        <div class=\"row\">\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                    <li><a href=\"#\">Dermitology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                            <div class=\"col-sm-6 col-12\">\r\n                                <ul class=\"list-unstyled list-style-3\">\r\n                                    <li><a href=\"#\">Cardiothoracic Surgery</a></li>\r\n                                    <li><a href=\"#\">Cardiovascular Diseases</a></li>\r\n                                    <li><a href=\"#\">Ophthalmology</a></li>\r\n                                </ul>\r\n                            </div>\r\n                        </div>', 'about1.jpg', 'about1.png', '{\"cta_title\":\"Get in touch to join our community\",\"button_text\":\"Contact Our Office\",\"button_url\":\"contact\"}', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_admission
#

DROP TABLE IF EXISTS `front_cms_admission`;

CREATE TABLE `front_cms_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `page_title` varchar(255) DEFAULT NULL,
  `terms_conditions_title` varchar(255) DEFAULT NULL,
  `terms_conditions_description` text NOT NULL,
  `fee_elements` text,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_admission` (`id`, `title`, `description`, `page_title`, `terms_conditions_title`, `terms_conditions_description`, `fee_elements`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Pré-inscription.', '<p>la pré-inscription pour les diplômes (Licence Professionnelle D\'UNIVERSITÉ et Master D\'UNIVERSITÉ) </p><p style=\"text-align: center; \"><b style=\"\">Année universitaire : 2021-2022</b><br></p>\r\n', 'S\'inscrire', 'Important', '<h5 class=\"alert alert-danger\" style=\"font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; border-radius: 4px; text-align: center;\"><b>Important:</b>Toute pré-candidature non conforme au dossier physique du candidat sera automatiquement&nbsp;<span class=\"animated infinite flash\" style=\"animation-iteration-count: infinite; color: red;\"><strong>rejetée.</strong></span></h5>', '[]', 'admission1.jpg', 'UCA - S\'inscrire formations continues', 'Formations continues uca', 1);


#
# TABLE STRUCTURE FOR: front_cms_admitcard
#

DROP TABLE IF EXISTS `front_cms_admitcard`;

CREATE TABLE `front_cms_admitcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `templete_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_admitcard` (`id`, `page_title`, `templete_id`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Admit Card', 1, 'admit_card1.jpg', 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.', 'Ramom - School Management System With CMS', 'Ramom Admit Card Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_certificates
#

DROP TABLE IF EXISTS `front_cms_certificates`;

CREATE TABLE `front_cms_certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_certificates` (`id`, `page_title`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Certificates', 'certificates1.jpg', 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.', 'Ramom - School Management System With CMS', 'Ramom Admit Card Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_contact
#

DROP TABLE IF EXISTS `front_cms_contact`;

CREATE TABLE `front_cms_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_title` varchar(255) DEFAULT NULL,
  `box_description` varchar(500) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `form_title` varchar(355) DEFAULT NULL,
  `address` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `submit_text` varchar(355) NOT NULL,
  `map_iframe` text,
  `page_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_contact` (`id`, `box_title`, `box_description`, `box_image`, `form_title`, `address`, `phone`, `email`, `submit_text`, `map_iframe`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Contactez-nous', '.', 'contact-info-box1.png', 'Une question ? N\'hésitez pas !', 'Av Abdelkrim Khattabi, B.P. 511 - 40000 -\r\nMarrakech', '(+212) 524 437 741,\r\n(+212) 524 434 814', 'ucacom@uca.ma', 'Envoyer', '<iframe width=\"100%\" height=\"350\" id=\"gmap_canvas\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3396.6675755640954!2d-8.021606684846386!3d31.642950981329214!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xdafee9c5c13471b%3A0x2cc2ac4063ddf13c!2sUniversit%C3%A9%20Cadi%20Ayyad%20(Pr%C3%A9sidence%2C%20Marrakech)!5e0!3m2!1sfr!2sma!4v1636403069074!5m2!1sfr!2sma\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\"></iframe>', 'Contactez-nous', 'contact1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq
#

DROP TABLE IF EXISTS `front_cms_faq`;

CREATE TABLE `front_cms_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_faq` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Frequently Asked Questions', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p>\r\n\r\n<p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven&#39;t heard of them accusamus labore sustainable VHS.</p>', 'Faq', 'faq1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq_list
#

DROP TABLE IF EXISTS `front_cms_faq_list`;

CREATE TABLE `front_cms_faq_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (1, 'Any Information you provide on applications for disability, life or accidental insurance ?', '<p>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n</p>\r\n<ul>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Sed do eiusmod tempor incididunt ut labore et dolore magna aliq.</li>\r\n<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact.</li>\r\n<li>That a reader will be distracted by the readable content of a page when looking at its layout.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>\r\n<li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n<li>Readable content of a page when looking at its layout.</li>\r\n<li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n<li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n</ul>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (2, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (3, 'Opposed to using \'Content here, content here\', making it look like readable English ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (4, 'Readable content of a page when looking at its layout ?', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (5, 'What types of documents are required to travel?', '<p><strong>Lorem ipsum</strong> dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, at usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. Per ad ullum lobortis. Duo volutpat imperdiet ut, postea salutatus imperdiet ut per, ad utinam debitis invenire has.</p>\r\n\r\n<ol>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n	<li>labores explicari quilabores explicari qui</li>\r\n	<li>labores explicari qui</li>\r\n</ol>', 1);


#
# TABLE STRUCTURE FOR: front_cms_home
#

DROP TABLE IF EXISTS `front_cms_home`;

CREATE TABLE `front_cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `item_type` varchar(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `elements` mediumtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `active` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (1, 'Formations continues', 'UCA', 'wellcome', 'Bienvenue sur le site de formation continue de l\'université UCA', '{\"image\":\"wellcome1.png\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (2, 'FORMATION CONTINUE DU PERSONNEL DE L\'UCA', NULL, 'teachers', 'La mission du Centre de Formation Continue de l\'UCA est d\'organiser, gérer et coordonner les actions de formation continue de l’Université et assurer leur suivi de concert avec les diverses composantes de l’université et ses partenaires.', '{\"teacher_start\":\"0\",\"image\":\"featured-parallax1.jpg\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (3, 'POURQUOI NOUS CHOISIR', NULL, 'services', '...', '', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (4, 'Request for a free Education Class', 'Medical Services', 'cta', '', '{\"mobile_no\":\"+2484-398-8987\",\"button_text\":\"Request Now\",\"button_url\":\"http:\\/\\/localhost\\/multi_pro\\/home\\/admission\\/\"}', 1, 0);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (5, 'Bienvenue sur le site officiel de  <span>Formation Continue</span> de UCA.', NULL, 'slider', '.', '{\"position\":\"c-left\",\"button_text1\":\"Voir plus de formations ...\",\"button_url1\":\"#\",\"button_text2\":\"UCA\",\"button_url2\":\"https.uca.ma\",\"image\":\"home-slider-1636124220.jpg\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (6, 'Un colloque <span>national</span> :', NULL, 'slider', 'L\'esprit d\'indépendance et ses perspectives à la lumière des nouvelles transformations internationales', '{\"position\":\"c-left\",\"button_text1\":\"Plus d\'informations ...\",\"button_url1\":\"https:\\/\\/www.uca.ma\\/fr\\/news\\/23932\",\"button_text2\":\"UCA News\",\"button_url2\":\"https:\\/\\/www.uca.ma\\/fr\\/news\",\"image\":\"home-slider-1638440940.jpg\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (7, 'Formation', NULL, 'features', 'Formation qualifiantes et certifiantes', '{\"button_text\":\"Read More\",\"button_url\":\"http:\\/\\/localhost\\/uca_v2\\/home\\/page\\/formations\",\"icon\":\"fab fa-studiovinari\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (8, 'Licence', NULL, 'features', 'Licence professionnelle d\'université.', '{\"button_text\":\"Read More\",\"button_url\":\"http:\\/\\/localhost\\/uca_v2\\/home\\/page\\/formations\",\"icon\":\"fas fa-book-reader\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (9, 'Master', NULL, 'features', 'Master professionnel d\'université.', '{\"button_text\":\"Read More\",\"button_url\":\"http:\\/\\/localhost\\/uca_v2\\/home\\/page\\/formations\",\"icon\":\"fas fa-graduation-cap\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (10, 'DUM', NULL, 'features', 'Diplôme universitaire médecine.', '{\"button_text\":\"Read More\",\"button_url\":\"http:\\/\\/localhost\\/uca_v2\\/home\\/page\\/formations\",\"icon\":\"fas fa-pills\"}', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (11, 'Témoignage', NULL, 'testimonial', '...', '', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `branch_id`, `active`) VALUES (12, 'Plus de 150 formations pluridisciplinaires vous attendent :', NULL, 'statistics', 'Dans le cadre de la mise en œuvre du programme d\'urgence, l\'Université Cadi Ayyad renforce son offre de formations par des filières adaptées aux besoins de l\'économie nationale.', '{\"image\":\"counter-parallax1.jpg\",\"widget_title_1\":\"Professeurs certifi\\u00e9s\",\"widget_icon_1\":\"fas fa-user-tie\",\"type_1\":\"teacher\",\"widget_title_2\":\"Etudiants\",\"widget_icon_2\":\"fas fa-user-graduate\",\"type_2\":\"student\",\"widget_title_3\":\"Cat\\u00e9gorie\",\"widget_icon_3\":\"fas fa-graduation-cap\",\"type_3\":\"class\",\"widget_title_4\":\"Fili\\u00e8re\",\"widget_icon_4\":\"fas fa-award\",\"type_4\":\"section\"}', 1, 1);


#
# TABLE STRUCTURE FOR: front_cms_home_seo
#

DROP TABLE IF EXISTS `front_cms_home_seo`;

CREATE TABLE `front_cms_home_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_home_seo` (`id`, `page_title`, `meta_keyword`, `meta_description`, `branch_id`) VALUES (1, 'UCA', 'Home Page', 'Université Cadi Ayyad ', 1);


#
# TABLE STRUCTURE FOR: front_cms_menu
#

DROP TABLE IF EXISTS `front_cms_menu`;

CREATE TABLE `front_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `open_new_tab` int(11) NOT NULL DEFAULT '0',
  `ext_url` tinyint(3) NOT NULL DEFAULT '0',
  `ext_url_address` text,
  `publish` tinyint(3) NOT NULL,
  `system` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (1, 'Home', 'index', 1, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (2, 'Events', 'events', 3, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (3, 'Teachers', 'teachers', 2, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (4, 'About Us', 'about', 4, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (5, 'FAQ', 'faq', 5, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (6, 'Online Admission', 'admission', 6, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (7, 'Contact Us', 'contact', 9, 0, 0, 0, '', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (8, 'Pages', 'pages', 8, 0, 0, 1, '#', 1, 1, 0, '2019-08-09 13:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (9, 'Admit Card', 'admit_card', 10, 8, 0, 0, '', 1, 1, 0, '2021-03-16 05:24:32');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (10, 'Exam Results', 'exam_results', 11, 8, 0, 0, '', 1, 1, 0, '2021-03-16 05:24:32');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (13, 'Certificates', 'certificates', 14, 8, 0, 0, '', 1, 1, 0, '2021-03-21 13:04:44');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (14, 'Gallery', 'gallery', 7, 0, 0, 0, '', 1, 1, 0, '2021-03-21 13:04:44');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (15, 'Formations', 'formations', 2, 0, 0, 0, '', 1, 0, 1, '2021-11-08 20:25:09');


#
# TABLE STRUCTURE FOR: front_cms_menu_visible
#

DROP TABLE IF EXISTS `front_cms_menu_visible`;

CREATE TABLE `front_cms_menu_visible` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `menu_id` int(11) NOT NULL,
  `parent_id` varchar(11) DEFAULT NULL,
  `ordering` varchar(20) DEFAULT NULL,
  `invisible` tinyint(2) NOT NULL DEFAULT '1',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (2, NULL, 8, NULL, NULL, 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (3, NULL, 9, NULL, NULL, 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (4, NULL, 10, NULL, NULL, 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (5, NULL, 13, NULL, NULL, 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (6, NULL, 14, NULL, NULL, 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (7, NULL, 3, NULL, NULL, 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (8, 'Acceuil', 1, '0', '1', 0, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (9, 'Évènement', 2, '0', '5', 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (10, 'S\'inscrire', 6, '0', '3', 0, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (11, 'Guide', 4, '0', '4', 1, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (12, 'Contactez-nous', 7, '0', '9', 0, 1);
INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (13, NULL, 5, NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: front_cms_pages
#

DROP TABLE IF EXISTS `front_cms_pages`;

CREATE TABLE `front_cms_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_pages` (`id`, `page_title`, `content`, `menu_id`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`, `created_at`) VALUES (1, 'Formations continues', '<h2 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);margin-bottom: 20px\"><u>Listes des formations continues</u></h2><h2 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0);\"><u>\r\n</u></h2><h3 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); margin-left: 25px;\"><font color=\"#ff0000\">Master</font></h3><h2><p style=\"margin-left: 50px;\"><span style=\"font-size: 14px; letter-spacing: normal;\"><span style=\"font-size: 18px;\">Actuariat et risk management</span><span style=\"white-space: pre; font-size: 18px;\">	</span></span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 14px; letter-spacing: normal;\"><span style=\"font-size: 18px;\">Management des ressources Humaines</span><span style=\"white-space: pre; font-size: 18px;\">	</span></span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 14px; letter-spacing: normal;\"><span style=\"font-size: 18px;\">Stratégie et Marketing des services</span><span style=\"white-space: pre; font-size: 18px;\">	</span></span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 14px; letter-spacing: normal;\"><span style=\"font-size: 18px;\">Ingénierie Génie Civil Environnement et qualité</span><span style=\"white-space: pre; font-size: 18px;\">	</span></span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 14px; letter-spacing: normal;\"><span style=\"font-size: 18px;\">Management Qualité Hygiène Sécurité et Environnement</span><span style=\"white-space: pre; font-size: 18px;\">	</span></span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 14px; letter-spacing: normal;\"><span style=\"font-size: 18px;\">Ingénierie des Systèmes Distribués et Cloud Computing</span><span style=\"white-space: pre; font-size: 18px;\">	</span></span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 18px; letter-spacing: normal;\">المنازعات القانونية</span></p><p style=\"margin-left: 50px;\"><span style=\"font-size: 18px; letter-spacing: normal;\"><br></span></p></h2><h3 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); margin-left: 25px;\"><font color=\"#ff0000\">Licence</font></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Finance , Banque et Assurance mode hybrid</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Data sciences appliquées en management et economie</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">logistique de distrubition et supply chain managemenet</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\"><br></span></h3><h3 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); margin-left: 25px;\"><font color=\"#ff0000\">Formation continue</font></h3><h3 style=\"margin-left: 50px;\"><span style=\"color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 18px;\">﻿</span><span style=\"font-size: 18px;\">Tutorat de langues étrangéres<font style=\"\"><br></font></span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Transport et logistique</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Community et revenue management touristique</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Préparation à l\'agrégation</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Accessibilité physique des personnes en situation d\'handicap</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Marketing digital</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\">Pédagogie unversitaire</span></h3><h3 style=\"margin-left: 50px;\"><span style=\"font-size: 18px;\"><br></span></h3><h3 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); margin-left: 25px;\"><font color=\"#ff0000\">Diplôme universitaire médecine</font></h3><h3 style=\"font-family: Arial, Helvetica, sans-serif; color: rgb(0, 0, 0); margin-left: 50px;\"><span style=\"font-size: 18px;\">﻿...</span><font color=\"#ff0000\"><br></font></h3>', 15, 'page_15.jpg', '', '', 1, '2021-11-08 20:26:40');


#
# TABLE STRUCTURE FOR: front_cms_services
#

DROP TABLE IF EXISTS `front_cms_services`;

CREATE TABLE `front_cms_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `parallax_image` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_services` (`id`, `title`, `subtitle`, `parallax_image`, `branch_id`) VALUES (1, 'Get Well Soon', 'Our Best <span>Services</span>', 'service_parallax1.jpg', 1);


#
# TABLE STRUCTURE FOR: front_cms_services_list
#

DROP TABLE IF EXISTS `front_cms_services_list`;

CREATE TABLE `front_cms_services_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `icon` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (2, 'Formations riches et variés.', '...', 'fas fa-book-open', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (3, 'Soyez un leader industriel', '...', 'fas fa-industry', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (4, 'Cours de programmation', '...', 'fas fa-code', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (5, 'Langues étrangères', '...', 'fas fa-language', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (7, 'Formation continue', '...', 'fab fa-studiovinari', 1);


#
# TABLE STRUCTURE FOR: front_cms_setting
#

DROP TABLE IF EXISTS `front_cms_setting`;

CREATE TABLE `front_cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(255) NOT NULL,
  `url_alias` varchar(255) DEFAULT NULL,
  `cms_active` tinyint(4) NOT NULL DEFAULT '0',
  `online_admission` tinyint(4) NOT NULL DEFAULT '0',
  `theme` varchar(255) NOT NULL,
  `captcha_status` varchar(20) NOT NULL,
  `recaptcha_site_key` varchar(255) NOT NULL,
  `recaptcha_secret_key` varchar(255) NOT NULL,
  `address` varchar(350) NOT NULL,
  `mobile_no` varchar(60) NOT NULL,
  `fax` varchar(60) NOT NULL,
  `receive_contact_email` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `copyright_text` varchar(255) NOT NULL,
  `fav_icon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `footer_about_text` varchar(300) NOT NULL,
  `working_hours` varchar(300) NOT NULL,
  `facebook_url` varchar(100) NOT NULL,
  `twitter_url` varchar(100) NOT NULL,
  `youtube_url` varchar(100) NOT NULL,
  `google_plus` varchar(100) NOT NULL,
  `linkedin_url` varchar(100) NOT NULL,
  `pinterest_url` varchar(100) NOT NULL,
  `instagram_url` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_setting` (`id`, `application_title`, `url_alias`, `cms_active`, `online_admission`, `theme`, `captcha_status`, `recaptcha_site_key`, `recaptcha_secret_key`, `address`, `mobile_no`, `fax`, `receive_contact_email`, `email`, `copyright_text`, `fav_icon`, `logo`, `footer_about_text`, `working_hours`, `facebook_url`, `twitter_url`, `youtube_url`, `google_plus`, `linkedin_url`, `pinterest_url`, `instagram_url`, `branch_id`) VALUES (1, 'Formations continues', 'uca', 1, 1, 'red', 'disable', '', '', 'Av Abdelkrim Khattabi, B.P. 511 - 40000 -', '(+212) 524 437 741   / (+212) 524 434 814', '(+212) 5 24 43 44 94', 'contact@uca.ma', 'ucacom@uca.ma', 'Copyright © 2021 <span>IRISI Student</span>. All Rights Reserved.', 'fav_icon1.png', 'logo1.png', 'CONTACT', '<span>Heures de travail : </span>  Lundi au Vendredi - 8AM - 18PM', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google.com', 'https://linkedin.com', 'https://pinterest.com', 'https://instagram.com', 1);


#
# TABLE STRUCTURE FOR: front_cms_teachers
#

DROP TABLE IF EXISTS `front_cms_teachers`;

CREATE TABLE `front_cms_teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_teachers` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Teachers', 'teachers1.jpg', 'Ramom - School Management System With CMS', 'Ramom  Teachers Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_testimonial
#

DROP TABLE IF EXISTS `front_cms_testimonial`;

CREATE TABLE `front_cms_testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(355) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rank` int(5) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (1, 'Pr. Moulay Lhassan HBID', 'Président de l\'Université Cadi Ayyad', 'user-1638441233.jpg', 'L’Université Cadi Ayyad (UCA) est l’une des universités publiques leaders à l’échelle nationale et régionale. Elle a veillé, depuis sa création en 1978, à assurer pleinement son rôle dans la création et la transmission du savoir, et à se démarquer dans la recherche et l’innovation. Au fil des années, elle s’est dotée d’autres structures qui ont renforcé davantage le paysage de l’enseignement supérieur.', 1, 1, 2, '2019-08-23 13:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (2, 'Hanane FARIS', 'Etudiante', 'user-1638441356.jpg', 'Je ne savais pas si j’allais m’habituer à ma nouvelle vie étudiante et j’ai eu peur de me sentir rejetée par mes collègues ou par les étudiants dans ma résidence. Et j’avais surtout peur de ne pas réussir mes examens à cause de mon faible niveau de français car je passais les examens comme une étudiante normale.', 4, 1, 2, '2019-08-23 13:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (3, 'R.ABDELGHANI BELLOUQUID', 'L’Université Cadi Ayyad', 'user-1638441364.jpg', 'L’UNIVERSITÉ CADI AYYAD ET SES CHERCHEURS FEU PR.ABDELGHANI BELLOUQUID ET LE PR.NASRRDDINE YOUBI PRIMÉS LORS DU \"RESEARCH EXCELLENCE DAY 2019\", MERCREDI 3 JUILLET 2019 À RABAT.', 5, 1, 2, '2019-08-23 13:26:42');


#
# TABLE STRUCTURE FOR: global_settings
#

DROP TABLE IF EXISTS `global_settings`;

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institute_name` varchar(255) NOT NULL,
  `institution_code` varchar(255) NOT NULL,
  `reg_prefix` varchar(255) NOT NULL,
  `institute_email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `currency_symbol` varchar(100) NOT NULL,
  `sms_service_provider` varchar(100) NOT NULL,
  `session_id` int(11) NOT NULL,
  `translation` varchar(100) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `animations` varchar(100) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `date_format` varchar(100) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `cron_secret_key` varchar(255) DEFAULT NULL,
  `preloader_backend` tinyint(1) NOT NULL DEFAULT '1',
  `cms_default_branch` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `global_settings` (`id`, `institute_name`, `institution_code`, `reg_prefix`, `institute_email`, `address`, `mobileno`, `currency`, `currency_symbol`, `sms_service_provider`, `session_id`, `translation`, `footer_text`, `animations`, `timezone`, `date_format`, `facebook_url`, `twitter_url`, `linkedin_url`, `youtube_url`, `cron_secret_key`, `preloader_backend`, `cms_default_branch`, `created_at`, `updated_at`) VALUES (1, 'UCA', 'UCA-', 'on', 'ramom@example.com', '', '0682484660', 'USD', '$', 'disabled', 3, 'french', '© 2021 UCA - Developed by an IRISI student', 'fadeInUp', 'Africa/Casablanca', 'd.M.Y', '', '', '', '', '32f718f60201187a044830845e34deb0', 1, 1, '2018-10-22 10:07:49', '2020-05-01 22:37:06');


#
# TABLE STRUCTURE FOR: language_list
#

DROP TABLE IF EXISTS `language_list`;

CREATE TABLE `language_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `lang_field` varchar(600) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (1, 'English', 'english', 1, '2018-11-15 12:36:31', '2020-04-18 20:05:12');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (3, 'Arabic', 'arabic', 1, '2018-11-15 12:36:31', '2019-01-20 03:04:53');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (4, 'French', 'french', 1, '2018-11-15 12:36:31', '2021-12-02 12:33:30');


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `english` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `arabic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `french` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1156 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1, 'language', 'Language', 'لغة', 'La langue');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (2, 'attendance_overview', 'Attendance Overview', 'نظرة عامة على الحضور', 'Aperçu de la fréquentation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (3, 'annual_fee_summary', 'Annual Fee Summary', 'ملخص الرسوم السنوية', 'Résumé des frais annuels');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (4, 'my_annual_attendance_overview', 'My Annual Attendance Overview', 'حضري السنوي نظرة عامة', 'Mon assiduité annuelle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (5, 'schedule', 'Schedule', 'جداول', 'des horaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (6, 'student_admission', 'Student Admission', 'قبول الطلاب', 'Admission des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (7, 'returned', 'Returned', 'عاد', 'Revenu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (8, 'user_name', 'User Name', 'اسم المستخدم', 'Nom d\'utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (9, 'rejected', 'Rejected', 'مرفوض', 'Rejeté');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (10, 'route_name', 'Route Name', 'اسم المسار', 'Nom de l\'itinéraire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (11, 'route_fare', 'Route Fare', 'الطريق الأجرة', 'Tarif d\'itinéraire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (12, 'edit_route', 'Edit Route', 'تحرير المسار', 'Modifier la route');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (13, 'this_value_is_required', 'This value is required.', 'هذه القيمة مطلوبة', 'Cette valeur est requise');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (14, 'vehicle_no', 'Vehicle No', 'السيارة لا', 'Numéro de véhicule');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (15, 'insurance_renewal_date', 'Insurance Renewal Date', 'تاريخ تجديد التأمين', 'Date de renouvellement de l&#39;assurance');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (16, 'driver_name', 'Driver Name', 'اسم السائق', 'Nom du conducteur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (17, 'driver_license', 'Driver License', 'رخصة قيادة', 'Permis de conduire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (18, 'select_route', 'Select Route', 'حدد الطريق', 'Sélectionnez l\'itinéraire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (19, 'edit_vehicle', 'Edit Vehicle', 'تحرير السيارة', 'Modifier le véhicule');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (20, 'add_students', 'Add Students', ' إضافة الطلاب', 'Ajouter des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (21, 'vehicle_number', 'Vehicle Number', 'عدد المركبات', 'Numéro de véhicule');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (22, 'select_route_first', 'Select Route First', 'حدد الطريق أولا', 'Sélectionnez l\'itinéraire d\'abord');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (23, 'transport_fee', 'Transport Fee', 'مصاريف الشحن', 'Frais de transport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (24, 'control', 'Control', 'مراقبة', 'contrôle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (25, 'set_students', 'Set Students', 'تعيين الطلاب', 'Mettre les élèves');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (26, 'hostel_list', 'Hostel List', 'قائمة نزل', 'Liste d\'auberges');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (27, 'watchman_name', 'Watchman Name', 'اسم الحارس', 'Nom du gardien');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (28, 'hostel_address', 'Hostel Address', 'عنوان الفندق', 'Adresse de l\'auberge');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (29, 'edit_hostel', 'Edit Hostel', 'تحرير نزل', 'Modifier hostel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (30, 'room_name', 'Room Name', 'اسم الغرفة', 'Nom de la salle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (31, 'no_of_beds', 'No Of Beds', 'عدد الأسرة', 'Nombre de lits');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (32, 'select_hostel_first', 'Select Hostel First', 'حدد نزل أولا', 'Sélectionnez l\'auberge en premier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (33, 'remaining', 'Remaining', 'متبق', 'Restant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (34, 'hostel_fee', 'Hostel Fee', 'رسوم النزل', 'Tarif de l\'auberge');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (35, 'accountant_list', 'Accountant List', 'قائمة المحاسبين', 'Liste comptable');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (36, 'students_fees', 'Students Fees', 'رسوم الطلاب', 'Frais d\'étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (37, 'fees_status', 'Fees Status', 'حالة الرسوم', 'Statut des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (38, 'books', 'Books', 'الكتب', 'livres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (39, 'home_page', 'Home Page', 'الصفحة الرئيسية', 'Page d\'accueil');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (40, 'collected', 'Collected', 'جمع', 'collecté');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (41, 'student_mark', 'Student Mark', 'علامة الطالب', 'Marque étudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (42, 'select_exam_first', 'Select Exam First', 'حدد الامتحان أولا', 'Sélectionnez l\'examen en premier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (43, 'transport_details', 'Transport Details', 'تفاصيل النقل', 'Détails de transport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (44, 'no_of_teacher', 'No of Teacher', 'لا المعلم', 'Nombre de professeurs');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (45, 'basic_details', 'Basic Details', 'تفاصيل أساسية', 'Détails de base');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (46, 'fee_progress', 'Fee Progress', 'رسوم التقدم', 'Progression des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (47, 'word', 'Word', 'كلمة', 'mot');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (48, 'book_category', 'Book Category', 'فئة الكتاب', 'Catégorie livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (49, 'driver_phone', 'Driver Phone', 'سائق الهاتف', 'Driver Phone');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (50, 'invalid_csv_file', 'Invalid / Corrupted CSV File', 'ملف كسف غير صالح / معطل', 'fichier CSV invalide / corrompu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (51, 'requested_book_list', 'Requested Book List', 'طلب قائمة الكتب', 'Liste de livres demandée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (52, 'request_status', 'Request Status', 'حالة الطلب', 'Statut de demande');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (53, 'book_request', 'Book Request', 'طلب الكتاب', 'Demande de livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (54, 'logout', 'Logout', 'الخروج', 'Connectez - Out');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (55, 'select_payment_method', 'Select Payment Method', 'اختار طريقة الدفع', 'Sélectionnez le mode de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (56, 'select_method', 'Select Method', 'حدد الطريقة', 'Méthode choisie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (57, 'payment', 'Payment', 'دفع', 'Paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (58, 'filter', 'Filter', 'منقي', 'Filtre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (59, 'status', 'Status', 'الحالة', 'statut');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (60, 'paid', 'Paid', 'دفع', 'Payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (61, 'unpaid', 'Unpaid', 'غير مدفوع', 'Non payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (62, 'method', 'Method', 'طريقة', 'la méthode');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (63, 'cash', 'Cash', 'السيولة النقدية', 'Argent liquide');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (64, 'check', 'Check', 'الاختيار', 'Vérifier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (65, 'card', 'Card', 'بطاقة', 'Carte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (66, 'payment_history', 'Payment History', 'تاريخ الدفع', 'historique de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (67, 'category', 'Category', 'فئة', 'Catégorie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (68, 'book_list', 'Book List', 'قائمة الكتب', 'Liste de livres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (69, 'author', 'Author', 'مؤلف', 'Auteur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (70, 'price', 'Price', 'السعر', 'Prix');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (71, 'available', 'Available', 'متاح', 'Disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (72, 'unavailable', 'Unavailable', 'غير متوفره', 'Indisponible');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (73, 'transport_list', 'Transport List', 'قائمة النقل', 'Liste des transports');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (74, 'edit_transport', 'Edit Transport', 'تحرير النقل', 'Modifier Transport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (75, 'hostel_name', 'Hostel Name', 'اسم المهجع', 'Nom Dortoir');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (76, 'number_of_room', 'Hostel Of Room', 'عدد الغرف', 'Nombre de chambres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (77, 'yes', 'Yes', 'نعم فعلا', 'Oui');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (78, 'no', 'No', 'لا', 'Non');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (79, 'messages', 'Messages', 'رسائل', 'messages');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (80, 'compose', 'Compose', 'إرسال رسالة جديدة', 'Ecrire un nouveau message');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (81, 'recipient', 'Recipient', 'مستلم', 'Bénéficiaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (82, 'select_a_user', 'Select A User', 'تحديد مستخدم', 'Sélectionnez un utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (83, 'send', 'Send', 'إرسال', 'Envoyer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (84, 'global_settings', 'Global Settings', 'اعدادات النظام', 'Les paramètres du système');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (85, 'currency', 'Currency', 'عملة', 'Devise');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (86, 'system_email', 'System Email', 'نظام البريد الإلكتروني', 'système Email');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (87, 'create', 'Create', 'خلق', 'créer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (88, 'save', 'Save', 'حفظ', 'sauvegarder');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (89, 'file', 'File', 'ملف', 'Fichier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (90, 'theme_settings', 'Theme Settings', 'إعدادات موضوع', 'Réglage des thèmes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (91, 'default', 'Default', 'افتراضي', 'Défaut');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (92, 'select_theme', 'Select Theme', 'اختر الموضوع', 'Sélectionne un thème');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (93, 'upload_logo', 'Upload Logo', 'تحميل الشعار', 'Télécharger Logo');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (94, 'upload', 'Upload', 'تحميل', 'Télécharger');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (95, 'remember', 'Remember', 'تذكر', 'Rappelles toi');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (96, 'not_selected', 'Not Selected', 'لم يتم اختياره', 'Non séléctionné');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (97, 'disabled', 'Disabled', 'معاق', 'désactivé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (98, 'inactive_account', 'Inactive Account', 'حساب غير نشط', 'Compte inactif');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (99, 'update_translations', 'Update Translations', 'تحديث الترجمات', 'actualiser les traductions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (100, 'language_list', 'Language List', 'قائمة لغة', 'Liste des langues');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (101, 'option', 'Option', 'خيار', 'Option');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (102, 'edit_word', 'Edit Word', 'تحرير الكلمة', 'modifier le mot');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (103, 'update_profile', 'Update Profile', 'تحديث الملف', 'Mettre à jour le profil');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (104, 'current_password', 'Current Password', 'كلمة السر الحالية', 'Mot de passe actuel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (105, 'new_password', 'New Password', 'كلمة السر الجديدة', 'nouveau mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (106, 'login', 'Login', 'تسجيل الدخول', 'S\'identifier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (107, 'reset_password', 'Reset Password', 'اعادة تعيين كلمة السر', 'réinitialiser le mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (108, 'present', 'Present', 'حاضر', 'Présent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (109, 'absent', 'Absent', 'غائب', 'Absent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (110, 'update_attendance', 'Update Attendance', 'تحديث الحضور', 'Mise à jour de présence');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (111, 'undefined', 'Undefined', 'غير محدد', 'Indéfini');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (112, 'back', 'Back', 'الى الخلف', 'Arrière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (113, 'save_changes', 'Save Changes', 'حفظ التغيرات', 'Sauvegarder les modifications');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (114, 'uploader', 'Uploader', 'رافع', 'Uploader');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (115, 'download', 'Download', 'تحميل', 'Télécharger');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (116, 'remove', 'Remove', 'إزالة', 'Retirer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (117, 'print', 'Print', 'طباعة', 'Impression');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (118, 'select_file_type', 'Select File Type', 'حدد نوع الملف', 'Sélectionner le type de fichier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (119, 'excel', 'Excel', 'تفوق', 'Exceller');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (120, 'other', 'Other', 'آخر', 'Autre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (121, 'students_of_class', 'Students Of Class', 'طلبة الدرجة', 'Les élèves du niveau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (122, 'marks_obtained', 'Marks Obtained', 'العلامات التي يحصل', 'Notes obtenues');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (123, 'attendance_for_class', 'Attendance For Class', 'الحضور لفئة', 'Participation Pour la classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (124, 'receiver', 'Receiver', 'المتلقي', 'Récepteur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (125, 'please_select_receiver', 'Please Select Receiver', 'الرجاء الإختيار استقبال', 'S\'il vous plaît Sélectionnez Receiver');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (126, 'session_changed', 'Session Changed', 'جلسة تغيير', 'session Changed');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (127, 'exam_marks', 'Exam Marks', 'علامات الامتحان', 'Marques d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (128, 'total_mark', 'Total Mark', 'عدد الأقسام', 'total Mark');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (129, 'mark_obtained', 'Mark Obtained', 'علامة حصل', 'Mark Obtenu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (130, 'invoice/payment_list', 'Invoice / Payment List', 'فاتورة / قائمة دفع', 'Facture / Liste de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (131, 'obtained_marks', 'Obtained Marks', 'العلامات التي تم الحصول عليها', 'Les notes obtenues');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (132, 'highest_mark', 'Highest Mark', 'أعلى الأقسام', 'le plus élevé Mark');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (133, 'grade', 'Grade (GPA)', 'درجة', 'Qualité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (134, 'dashboard', 'Dashboard', 'لوحة القيادة', 'Tableau de bord');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (135, 'student', 'Student', 'طالب علم', 'Élève');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (136, 'rename', 'Rename', 'إعادة تسمية', 'rebaptiser');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (137, 'class', 'Class', 'صف مدرسي', 'Les diplômes ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (138, 'teacher', 'Teacher', 'مدرس', 'Professeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (139, 'parents', 'Parents', 'الآباء', 'Des parents');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (140, 'subject', 'Subject', 'موضوع', 'Sujet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (141, 'student_attendance', 'Student Attendance', 'حضور الطالب', 'Participation des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (142, 'exam_list', 'Exam List', 'قائمة الامتحان', 'Liste d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (143, 'grades_range', 'Grades Range', 'مجموعة الدرجات', 'Gamme de notes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (144, 'loading', 'Loading', 'جار التحميل', 'chargement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (145, 'library', 'Library', 'مكتبة', 'Bibliothèque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (146, 'hostel', 'Hostel', 'المهجع', 'Dortoir');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (147, 'events', 'Events', 'اللافتة', 'Tableau d\'affichage');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (148, 'message', 'Message', 'الرسالة', 'Message');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (149, 'translations', 'Translations', 'ترجمة', 'traductions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (150, 'account', 'Account', 'حساب', 'Compte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (151, 'selected_session', 'Selected Session', 'جلسة مختارة', 'session sélectionnée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (152, 'change_password', 'Change Password', 'تغيير كلمة السر', 'Changer le mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (153, 'section', 'Section', 'قسم', 'Filière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (154, 'edit', 'Edit', 'تحرير', 'modifier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (155, 'delete', 'Delete', 'حذف', 'Effacer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (156, 'cancel', 'Cancel', 'إلغاء', 'Annuler');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (157, 'parent', 'Parent', 'أصل', 'Parent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (158, 'attendance', 'Attendance', 'الحضور', 'Présence');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (159, 'addmission_form', 'Admission Form', 'شكل القبول', 'Formulaire d\'admission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (160, 'name', 'Name', 'اسم', 'Nom');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (161, 'select', 'Select', 'اختار', 'Sélectionner');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (162, 'roll', 'Roll', 'لفة', 'Roulent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (163, 'birthday', 'Date Of Birth', 'تاريخ الميلاد', 'Anniversaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (164, 'gender', 'Gender', 'جنس', 'Le genre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (165, 'male', 'Male', 'ذكر', 'Mâle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (166, 'female', 'Female', 'أنثى', 'Femelle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (167, 'address', 'Address', 'عنوان', 'Adresse');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (168, 'phone', 'Phone', 'هاتف', 'Téléphone');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (169, 'email', 'Email', 'البريد الإلكتروني', 'Email');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (170, 'password', 'Password', 'كلمه السر', 'Mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (171, 'transport_route', 'Transport Route', 'النقل الطريق', 'Transport Route');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (172, 'photo', 'Photo', 'صورة فوتوغرافية', 'photo');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (173, 'select_class', 'Select Class', 'حدد فئة', 'Sélectionnez un diplôme');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (174, 'username_password_incorrect', 'Username Or Password Is Incorrect', 'اسم المستخدم أو كلمة المرور غير صحيحة', 'L\'identifiant ou le mot de passe est incorrect');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (175, 'select_section', 'Select Section', 'حدد القسم', 'Sélectionnez une filière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (176, 'options', 'Options', 'خيارات', 'options de');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (177, 'mark_sheet', 'Mark Sheet', 'ورقة علامة', 'Mark Sheet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (178, 'profile', 'Profile', 'الملف الشخصي', 'Profil');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (179, 'select_all', 'Select All', 'اختر الكل', 'Sélectionner tout');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (180, 'select_none', 'Select None', 'حدد بلا', 'Ne rien sélectionner');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (181, 'average', 'Average', 'متوسط', 'Moyenne');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (182, 'transfer', 'Transfer', 'تحويل', 'transfert');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (183, 'edit_teacher', 'Edit Teacher', 'تحرير المعلم', 'Modifier enseignant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (184, 'sex', 'Sex', 'جنس', 'Sexe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (185, 'marksheet_for', 'Marksheet For', 'ورقة علامة ل', 'Marquer les feuilles pour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (186, 'total_marks', 'Total Marks', 'مجموع الدرجات', 'total de points');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (187, 'parent_phone', 'Parent Phone', 'الأم الهاتف', 'Parent téléphone');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (188, 'subject_author', 'Subject Author', 'الموضوع المؤلف', 'Sujet Auteur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (189, 'update', 'Update', 'تحديث', 'Mettre à jour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (190, 'class_list', 'Class List', 'قائمة الطبقة', 'Liste des diplômes ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (191, 'class_name', 'Class Name', 'اسم الطبقة', 'Niveau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (192, 'name_numeric', 'Name Numeric', 'اسم الرقمية', 'Nom numérique');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (193, 'select_teacher', 'Select Teacher', 'حدد المعلم', 'Sélectionnez ce professeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (194, 'edit_class', 'Edit Class', 'تحرير الفئة', 'Modifier le nom du niveau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (195, 'section_name', 'Section Name', 'اسم القسم', 'Nom de la filière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (196, 'add_section', 'Add Section', 'إضافة مقطع', 'Ajouter une filière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (197, 'subject_list', 'Subject List', 'قائمة الموضوع', 'Liste Sujet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (198, 'subject_name', 'Subject Name', 'اسم الموضوع', 'Nom Sujet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (199, 'edit_subject', 'Edit Subject', 'تحرير الموضوع', 'Modifier Objet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (200, 'day', 'Day', 'يوم', 'journée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (201, 'starting_time', 'Starting Time', 'ابتداء من الوقت', 'Heure de départ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (202, 'hour', 'Hour', 'ساعة', 'Heure');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (203, 'minutes', 'Minutes', 'دقيقة', 'Minutes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (204, 'ending_time', 'Ending Time', 'إنهاء الوقت', 'Fin Temps');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (205, 'select_subject', 'Select Subject', 'حدد الموضوع', 'Sélectionnez Objet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (206, 'select_date', 'Select Date', 'حدد التاريخ', 'Sélectionnez date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (207, 'select_month', 'Select Month', 'اختر الشهر', 'Sélectionnez un mois');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (208, 'select_year', 'Select Year', 'اختر السنة', 'Sélectionnez Année');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (209, 'add_language', 'Add Language', 'إضافة لغة', 'ajouter une langue');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (210, 'exam_name', 'Exam Name', 'اسم الامتحان', 'Nom d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (211, 'date', 'Date', 'تاريخ', 'date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (212, 'comment', 'Comment', 'التعليق', 'Commentaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (213, 'edit_exam', 'Edit Exam', 'تحرير امتحان', 'Modifier examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (214, 'grade_list', 'Grade List', 'قائمة الصف', 'Liste de grade');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (215, 'grade_name', 'Grade Name', 'اسم الصف', 'Nom de grade');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (216, 'grade_point', 'Grade Point', 'الصف نقطة', 'grade point');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (217, 'select_exam', 'Select Exam', 'حدد الامتحان', 'Sélectionnez Exam');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (218, 'students', 'Students', 'الطلاب', 'Élèves');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (219, 'subjects', 'Subjects', 'المواضيع', 'Sujets');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (220, 'total', 'Total', 'مجموع', 'Total');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (221, 'select_academic_session', 'Select Academic Session', 'حدد الدورة الأكاديمية', 'Séance scolaire sélectionnée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (222, 'invoice_informations', 'Invoice Informations', 'معلومات الفاتورة', 'Informations de facturation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (223, 'title', 'Title', 'عنوان', 'Titre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (224, 'description', 'Description', 'وصف', 'La description');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (225, 'payment_informations', 'Payment Informations', 'معلومات الدفع', 'Informations de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (226, 'view_invoice', 'View Invoice', 'عرض الفاتورة', 'Voir la facture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (227, 'payment_to', 'Payment To', 'دفع ل', 'Paiement à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (228, 'bill_to', 'Bill To', 'فاتورة الى', 'Facturer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (229, 'total_amount', 'Total Amount', 'المبلغ الإجمالي', 'Montant total');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (230, 'paid_amount', 'Paid Amount', 'المبلغ المدفوع', 'Montant payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (231, 'due', 'Due', 'بسبب', 'Dû');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (232, 'amount_paid', 'Amount Paid', 'المبلغ المدفوع', 'Le montant payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (233, 'payment_successfull', 'Payment has been successful', 'دفع النجاح', 'Paiement Successfull');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (234, 'add_invoice/payment', 'Add Invoice/payment', 'إضافة فاتورة / دفع', 'Ajouter Facture / paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (235, 'invoices', 'Invoices', 'الفواتير', 'factures');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (236, 'action', 'Action', 'عمل', 'action');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (237, 'required', 'Required', 'مطلوب', 'Obligatoire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (238, 'info', 'Info', 'معلومات', 'Info');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (239, 'month', 'Month', '\r\nشهر', 'mois');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (240, 'details', 'Details', 'تفاصيل', 'Détails');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (241, 'new', 'New', 'الجديد', 'Nouveau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (242, 'reply_message', 'Reply Message', 'رسالة الرد', 'Réponse au message');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (243, 'message_sent', 'Message Sent', 'تم الارسال', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (244, 'search', 'Search', 'بحث', 'chercher');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (245, 'religion', 'Religion', 'دين', 'Religion');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (246, 'blood_group', 'Blood group', 'فصيلة الدم', 'groupe sanguin');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (247, 'database_backup', 'Database Backup', 'قاعدة بيانات النسخ الاحتياطي', 'Sauvegarde de base de données');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (248, 'search', 'Search', 'بحث', 'chercher');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (249, 'payments_history', 'Fees Pay / Invoice', 'رسوم الدفع / الفاتورة', 'honoraires payer / facture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (250, 'message_restore', 'Message Restore', 'استعادة الرسائل', 'Restauration de message');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (251, 'write_new_message', 'Write New Message', 'إرسال رسالة جديدة', 'Ecrire un nouveau message');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (252, 'attendance_sheet', 'Attendance Sheet', 'ورقة الحضور', 'Feuille de présence');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (253, 'holiday', 'Holiday', 'يوم الاجازة', 'Vacances');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (254, 'exam', 'Exam', 'امتحان', 'Examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (255, 'successfully', 'Successfully', 'بنجاح', 'Avec succès');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (256, 'admin', 'Admin', 'مشرف', 'Admin');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (257, 'inbox', 'Inbox', 'صندوق الوارد', 'Boîte de réception');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (258, 'sent', 'Sent', 'أرسلت', 'Envoyé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (259, 'important', 'Important', 'مهم', 'Important');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (260, 'trash', 'Trash', 'قمامة، يدمر، يهدم', 'Poubelle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (261, 'error', 'Unsuccessful', 'غير ناجحة', 'Infructueux');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (262, 'sessions_list', 'Sessions List', 'قائمة الجلسات', 'Liste des sessions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (263, 'session_settings', 'Session Settings', 'إعدادات الجلسة', 'Paramètres de la session');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (264, 'add_designation', 'Add Designation', 'إضافة تسمية', 'Ajouter une désignation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (265, 'users', 'Users', 'المستخدمين', 'Utilisateurs');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (266, 'librarian', 'Librarian', 'أمين المكتبة', 'Bibliothécaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (267, 'accountant', 'Accountant', 'محاسب', 'Comptable');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (268, 'academics', 'Academics', 'مؤسسيا', 'institutionnellement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (269, 'employees_attendance', 'Employees Attendance', 'حضور الموظفين', 'Participation des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (270, 'set_exam_term', 'Set Exam Term', 'تعيين مدة الامتحان', 'Terminer l\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (271, 'set_attendance', 'Set Attendance', 'تعيين الحضور', 'Assurer la fréquentation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (272, 'marks', 'Marks', 'علامات', 'Des notes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (273, 'books_category', 'Books Category', 'فئة الكتاب', 'Catégorie de livres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (274, 'transport', 'Transport', 'المواصلات', 'Transport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (275, 'fees', 'Fees', 'رسوم', 'honoraires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (276, 'fees_allocation', 'Fees Allocation', 'توزيع الرسوم', 'répartition des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (277, 'fee_category', 'Fee Category', 'فئة الرسوم', 'Catégorie tarifaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (278, 'report', 'Report', 'أبلغ عن', 'rapport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (279, 'employee', 'Employee', 'الموظفين', 'employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (280, 'invoice', 'Invoice', 'فاتورة', 'facture d\'achat');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (281, 'event_catalogue', 'Event Catalogue', 'كتالوج الأحداث', 'Catalogue des événements');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (282, 'total_paid', 'Total Paid', 'مجموع المبالغ المدفوعة', 'Total payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (283, 'total_due', 'Total Due', 'الاجمالي المستحق', 'Total dû');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (284, 'fees_collect', 'Fees Collect', 'تحصيل الرسوم', 'Frais collectés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (285, 'total_school_students_attendance', 'Total School Students Attendance', 'مجموع طلاب المدارس الحضور', 'Participation totale des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (286, 'overview', 'Overview', 'نظرة عامة', 'Aperçu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (287, 'currency_symbol', 'Currency Symbol', 'رمز العملة', 'symbole de la monnaie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (288, 'enable', 'Enable', 'مكن', 'Activer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (289, 'disable', 'Disable', 'تعطيل', 'Désactiver');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (290, 'payment_settings', 'Payment Settings', 'إعدادات الدفع', 'Paramètres de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (291, 'student_attendance_report', 'Student Attendance Report', 'تقرير حضور الطالب', 'Rapport de présence étudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (292, 'attendance_type', 'Attendance Type', 'نوع الحضور', 'Type de présence');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (293, 'late', 'Late', 'متأخر', 'En retard');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (294, 'employees_attendance_report', 'Employees Attendance Report', 'الموظفين تقرير الحضور', 'Rapport de présence des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (295, 'attendance_report_of', 'Attendance Report Of', 'تقرير الحضور من', 'Rapport de présence de');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (296, 'fee_paid_report', 'Fee Paid Report', 'الرسوم المدفوعة التقرير', 'Rapport payé payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (297, 'invoice_no', 'Invoice No', 'رقم الفاتورة', 'Facture non');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (298, 'payment_mode', 'Payment Mode', 'طريقة الدفع', 'mode de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (299, 'payment_type', 'Payment Type', 'نوع الدفع', 'type de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (300, 'done', 'Done', 'فعله', 'terminé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (301, 'select_fee_category', 'Select Fee Category', 'حدد فئة الرسوم', 'Sélectionner la catégorie tarifaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (302, 'discount', 'Discount', 'خصم', 'remise');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (303, 'enter_discount_amount', 'Enter Discount Amount', 'أدخل مبلغ الخصم', 'Saisir un montant d\'escompte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (304, 'online_payment', 'Online Payment', 'الدفع عن بعد', 'Paiement à distance');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (305, 'student_name', 'Student Name', 'أسم الطالب', 'nom d\'étudiant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (306, 'invoice_history', 'Invoice History', 'تاريخ الفاتورة', 'Historique des factures');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (307, 'discount_amount', 'Discount Amount', 'مقدار الخصم', 'Montant de l\'escompte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (308, 'invoice_list', 'Invoice List', 'قائمة الفاتورة', 'Liste des factures');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (309, 'partly_paid', 'Partly Paid', 'تدفع جزئيا', 'En partie payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (310, 'fees_list', 'Fees List', 'قائمة الرسوم', 'Liste des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (311, 'voucher_id', 'Voucher ID', 'معرف القسيمة', 'Id de bon');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (312, 'transaction_date', 'Transaction Date', 'تاريخ الصفقة', 'transaction date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (313, 'admission_date', 'Admission Date', 'تاريخ القبول', 'admission date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (314, 'user_status', 'User Status', 'حالة المستخدم', 'Statut de l\'utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (315, 'nationality', 'Nationality', 'جنسية', 'nationalité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (316, 'register_no', 'Register No', 'سجل رقم', 'Inscrivez-vous non');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (317, 'first_name', 'First Name', 'الاسم الاول', 'Prénom');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (318, 'last_name', 'Last Name', 'الكنية', 'nom de famille');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (319, 'state', 'State', 'حالة', 'Etat');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (320, 'transport_vehicle_no', 'Transport Vehicle No', 'رقم مركبة النقل', 'Véhicule de transport no');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (321, 'percent', 'Percent', 'نسبه مئويه', 'pour cent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (322, 'average_result', 'Average Result', 'متوسط ​​النتيجة', 'Résultat moyen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (323, 'student_category', 'Student Category', 'طالب', 'Catégorie étudiante');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (324, 'category_name', 'Category Name', 'اسم التصنيف', 'Nom de catégorie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (325, 'category_list', 'Category List', 'قائمة الفئات', 'Liste des catégories');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (326, 'please_select_student_first', 'Please Select Students First', 'يرجى اختيار الطلاب أولا', 'S\'il vous plaît sélectionner les étudiants de première');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (327, 'designation', 'Designation', 'تعيين', 'La désignation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (328, 'qualification', 'Qualification', 'المؤهل', 'Qualification');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (329, 'account_deactivated', 'Account Deactivated', 'تم إلغاء تنشيط الحساب', 'Compte désactivé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (330, 'account_activated', 'Account Activated', 'تم تنشيط الحساب', 'Compte activé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (331, 'designation_list', 'Designation List', 'قائمة التعيين', 'Liste de désignation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (332, 'joining_date', 'Joining Date', 'تاريخ الانضمام', 'Date d\'inscription');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (333, 'relation', 'Relation', 'علاقة', 'Relation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (334, 'father_name', 'Father Name', 'اسم الأب', 'nom du père');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (335, 'librarian_list', 'Librarian List', 'قائمة أمين المكتبة', 'Liste des bibliothécaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (336, 'class_numeric', 'Class Numeric', 'فئة رقمية', 'Classe Numérique');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (337, 'maximum_students', 'Maximum Students', 'الحد الأقصى للطلاب', 'Maximum d\'étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (338, 'class_room', 'Class Room', 'قاعة الدراسة', 'Salle de classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (339, 'pass_mark', 'Pass Mark', 'علامة المرور', 'moyenne');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (340, 'exam_time', 'Exam Time (Min)', 'وقت الامتحان', 'Temps d\'examen (min)');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (341, 'time', 'Time', 'زمن', 'temps');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (342, 'subject_code', 'Subject Code', 'رمز الموضوع', 'Code du sujet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (343, 'full_mark', 'Full Mark', 'درجة كاملة', 'Pleine marque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (344, 'subject_type', 'Subject Type', 'نوع الموضوع', 'Type de sujet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (345, 'date_of_publish', 'Date Of Publish', 'تاريخ النشر', 'Date de publication');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (346, 'file_name', 'File Name', 'اسم الملف', 'Nom de fichier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (347, 'students_list', 'Students List', 'قائمة الطلاب', 'Liste des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (348, 'start_date', 'Start Date', 'تاريخ البدء', 'Date de début');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (349, 'end_date', 'End Date', 'تاريخ الانتهاء', 'End Date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (350, 'term_name', 'Term Name', 'اسم المدى', 'Nom du terme');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (351, 'grand_total', 'Grand Total', 'المبلغ الإجمالي', 'Grand Total');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (352, 'result', 'Result', 'نتيجة', 'Résultat');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (353, 'books_list', 'Books List', 'قائمة الكتب', 'Liste des livres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (354, 'book_isbn_no', 'Book ISBN No', 'كتاب رقم إيسبن رقم', 'Livre numéro ISBN');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (355, 'total_stock', 'Total Stock', 'إجمالي الأسهم', 'Total Stock');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (356, 'issued_copies', 'Issued Copies', 'تم إصدار نسخ', 'Copies émises');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (357, 'publisher', 'Publisher', 'الناشر', 'éditeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (358, 'books_issue', 'Books Issue', 'كتاب المسألة', 'Problème de livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (359, 'user', 'User', 'المستعمل', 'Utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (360, 'fine', 'Fine', 'غرامة', 'Bien');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (361, 'pending', 'Pending', 'قيد الانتظار', 'en attendant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (362, 'return_date', 'Return Date', 'تاريخ العودة', 'date de retour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (363, 'accept', 'Accept', 'قبول', 'Acceptez');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (364, 'reject', 'Reject', 'رفض', 'rejeter');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (365, 'issued', 'Issued', 'نشر', 'Publié');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (366, 'return', 'Return', 'إرجاع', 'Revenir');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (367, 'renewal', 'Renewal', 'تجديد', 'renouvellement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (368, 'fine_amount', 'Fine Amount', 'كمية غرامة', 'Montant fin');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (369, 'password_mismatch', 'Password Mismatch', 'عدم تطابق كلمة المرور', 'Incompatibilité de mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (370, 'settings_updated', 'Settings Update', 'تحديث الإعدادات', 'Mise à jour de paramètres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (371, 'pass', 'Pass', 'البشري', 'passer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (372, 'event_to', 'Event To', 'الحدث ل', 'Événement à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (373, 'all_users', 'All Users', 'جميع المستخدمين', 'tous les utilisateurs');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (374, 'employees_list', 'Employees List', 'قائمة الموظفين', 'Liste des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (375, 'on', 'On', 'على', 'sur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (376, 'timezone', 'Timezone', 'وحدة زمنية', 'fuseau horaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (377, 'get_result', 'Get Result', 'الحصول على نتيجة', 'Obtenir un résultat');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (378, 'apply', 'Apply', 'تطبيق', 'appliquer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (379, 'hrm', 'Human Resource', 'الموارد البشرية', 'ressource humaine');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (380, 'payroll', 'Payroll', 'كشف رواتب', 'paie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (381, 'salary_assign', 'Salary Assign', 'مراقبة الرواتب', 'Contrôle des salaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (382, 'employee_salary', 'Payment Salary', 'دفع الراتب', 'Salaire de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (383, 'application', 'Application', 'الوضعية', 'application');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (384, 'award', 'Award', 'جائزة', 'prix');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (385, 'basic_salary', 'Basic Salary', 'راتب اساسي', 'salaire de base');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (386, 'employee_name', 'Employee Name', 'اسم الموظف', 'Nom de l\'employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (387, 'name_of_allowance', 'Name Of Allowance', 'اسم البدل', 'nom de l\'allocation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (388, 'name_of_deductions', 'Name Of Deductions', 'اسم الاستقطاعات', 'Nom des déductions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (389, 'all_employees', 'All Employees', 'كل الموظفين', 'tous les employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (390, 'total_allowance', 'Total Allowance', 'مجموع المخصصات', 'Allocation totale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (391, 'total_deduction', 'Total Deductions', 'مجموع الخصومات', 'le total des déductions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (392, 'net_salary', 'Net Salary', 'صافي الراتب', 'salaire net');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (393, 'payslip', 'Payslip', 'قسيمة الدفع', 'Payslip');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (394, 'days', 'Days', 'أيام', 'journées');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (395, 'category_name_already_used', 'Category Name Already Used', 'اسم الفئة المستخدمة من قبل', 'Nom de la catégorie déjà utilisé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (396, 'leave_list', 'Leave List', 'قائمة الإجازات', 'Laisser liste');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (397, 'leave_category', 'Leave Category', 'ترك الفئة', 'Laisser la catégorie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (398, 'applied_on', 'Applied On', 'تطبيق على', 'appliqué sur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (399, 'accepted', 'Accepted', 'قبلت', 'accepté');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (400, 'leave_statistics', 'Leave Statistics', 'وترك الإحصاءات', 'Quitter les statistiques');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (401, 'leave_type', 'Leave Type', 'نوع الإجازة', 'Type de permission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (402, 'reason', 'Reason', 'السبب', 'raison');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (403, 'close', 'Close', 'أغلق', 'Fermer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (404, 'give_award', 'Give Award', 'إعطاء الجائزة', 'Donner un prix');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (405, 'list', 'List', 'قائمة', 'liste');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (406, 'award_name', 'Award Name', 'اسم الجائزة', 'nom de l\'attribution');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (407, 'gift_item', 'Gift Item', 'هدية البند', 'Objet cadeau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (408, 'cash_price', 'Cash Price', 'سعر الصرف', 'Prix ​​en espèces');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (409, 'award_reason', 'Award Reason', 'جائزة السبب', 'Raison de récompense');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (410, 'given_date', 'Given Date', 'تاريخ معين', 'Date donnée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (411, 'apply_leave', 'Apply Leave', 'تطبيق الإجازة', 'Postuler');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (412, 'leave_application', 'Leave Application', 'اترك التطبيق', 'laisser l\'application');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (413, 'allowances', 'Allowances', 'البدلات', 'Allocations');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (414, 'add_more', 'Add More', 'أضف المزيد', 'ajouter plus');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (415, 'deductions', 'Deductions', 'الخصومات', 'Déductions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (416, 'salary_details', 'Salary Details', 'تفاصيل الراتب', 'Détails de salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (417, 'salary_month', 'Salary Month', 'راتب شهر', 'Mois de salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (418, 'leave_data_update_successfully', 'Leave Data Updated Successfully', 'ترك البيانات تحديثها بنجاح', 'Laisser les données mises à jour avec succès');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (419, 'fees_history', 'Fees History', 'تاريخ الرسوم', 'Historique des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (420, 'bank_name', 'Bank Name', 'اسم البنك', 'Nom de banque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (421, 'branch', 'Branch', 'فرع شجرة', 'branche');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (422, 'bank_address', 'Bank Address', 'عنوان البنك', 'adresse de la banque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (423, 'ifsc_code', 'IFSC Code', 'رمز إفسك', 'IFSC code');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (424, 'account_no', 'Account No', 'رقم الحساب', 'n ° de compte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (425, 'add_bank', 'Add Bank', 'إضافة بنك', 'Ajouter une banque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (426, 'account_name', 'Account Holder', 'أسم الحساب', 'nom du compte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (427, 'database_backup_completed', 'Database Backup Completed', 'اكتمل قاعدة بيانات النسخ الاحتياطي', 'Sauvegarde de base de données terminée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (428, 'restore_database', 'Restore Database', 'استعادة قاعدة البيانات', 'Restaurer la base de données');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (429, 'template', 'Template', 'قالب', 'modèle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (430, 'time_and_date', 'Time And Date', 'الوقت و التاريخ', 'heure et date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (431, 'everyone', 'Everyone', 'كل واحد', 'toutes les personnes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (432, 'invalid_amount', 'Invalid Amount', 'مبلغ غير صحيح', 'montant invalide');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (433, 'leaving_date_is_not_available_for_you', 'Leaving Date Is Not Available For You', 'ترك التاريخ غير متاح لك', 'la date de sortie n\'est pas disponible pour vous');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (434, 'animations', 'Animations', 'الرسوم المتحركة', 'animations');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (435, 'email_settings', 'Email Settings', 'إعدادات البريد الإلكتروني', 'Paramètres de messagerie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (436, 'deduct_month', 'Deduct Month', 'خصم الشهر', 'déduire le mois');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (437, 'no_employee_available', 'No Employee Available', 'لا يتوفر موظف', 'Aucun employé disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (438, 'advance_salary_application_submitted', 'Advance Salary Application Submitted', 'تم تقديم طلب الراتب المتقدم', 'Demande de salaire anticipé soumise');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (439, 'date_format', 'Date Format', 'صيغة التاريخ', 'date format');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (440, 'id_card_generate', 'ID Card Generate', 'بطاقة الهوية تولد', 'Carte d\'identité générer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (441, 'issue_salary', 'Issue Salary', 'إصدار الراتب', 'question salariale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (442, 'advance_salary', 'Advance Salary', 'راتب مقدما', 'avance sur salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (443, 'logo', 'Logo', 'شعار', 'logo');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (444, 'book_request', 'Book Request', 'طلب الكتاب', 'demande de livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (445, 'reporting', 'Reporting', 'التقارير', 'rapport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (446, 'paid_salary', 'Paid Salary', 'الراتب المدفوع', 'salaire payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (447, 'due_salary', 'Due Salary', 'الراتب', 'salaire dû');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (448, 'route', 'Route', 'طريق', 'Route');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (449, 'academic_details', 'Academic Details', 'التفاصيل الأكاديمية', 'détails académiques');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (450, 'guardian_details', 'Guardian Details', 'التفاصيل الأكاديمية', 'détails académiques');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (451, 'due_amount', 'Due Amount', 'مبلغ مستحق', 'montant dû');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (452, 'fee_due_report', 'Fee Due Report', 'تقرير الرسوم المستحقة', 'rapport dû');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (453, 'other_details', 'Other Details', 'تفاصيل أخرى', 'Autres détails');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (454, 'last_exam_report', 'Last Exam Report', 'تقرير الاختبار الأخير', 'Dernier rapport d&#39;examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (455, 'book_issued', 'Book Issued', ' كتاب صدر', 'Livre publié');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (456, 'interval_month', 'Interval 30 Days', 'الفاصل الزمني 30 يومًا', 'Intervalle 30 jours');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (457, 'attachments', 'Attachments', 'مرفقات', 'Les pièces jointes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (458, 'fees_payment', 'Fees Payment', 'دفع الرسوم', 'Paiement des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (459, 'fees_summary', 'Fees Summary', 'ملخص الرسوم', 'Résumé des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (460, 'total_fees', 'Total Fees', 'الرسوم الكلية', 'Total des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (461, 'weekend_attendance_inspection', 'Weekend Attendance Inspection', 'فحص الحضور في عطلة نهاية الاسبوع', 'Weekend Attendance Inspection');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (462, 'book_issued_list', 'Book Issued List', 'كتاب صدر قائمة', 'Liste des livres publiés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (463, 'lose_your_password', 'Lose Your Password?', '?تفقد كلمة المرور الخاصة بك', 'Perdre votre mot de passe?');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (464, 'all_branch_dashboard', 'All Branch Dashboard', 'كل لوحة فرع', 'Tableau de bord de toutes les branches');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (465, 'academic_session', 'Academic Session', 'الدورة الأكاديمية', 'Session académique');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (466, 'all_branches', 'All Branches', 'كل الفروع', 'Heures supplémentaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (467, 'admission', 'Admission', 'قبول', 'admission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (468, 'create_admission', 'Create Admission', 'إنشاء القبول', 'Créer une entrée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (469, 'multiple_import', 'Multiple Import', 'استيراد متعدد', 'Importation multiple');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (470, 'student_details', 'Student Details', 'تفاصيل الطالب', 'Détails de l\'étudiant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (471, 'student_list', 'Student List', 'قائمة الطلاب', 'Liste des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (472, 'login_deactivate', 'Login Deactivate', 'تسجيل الدخول', 'Login Désactiver');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (473, 'parents_list', 'Parents List', 'قائمة الوالدين', 'Liste de parents');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (474, 'add_parent', 'Add Parent', 'أضف الوالد', 'Ajouter un parent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (475, 'employee_list', 'Employee List', 'قائمة موظف', 'Liste des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (476, 'add_department', 'Add Department', 'أضف قسم', 'Ajouter un département');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (477, 'add_employee', 'Add Employee', 'إضافة موظف', 'Ajouter un employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (478, 'salary_template', 'Salary Template', 'قالب الراتب', 'Modèle de salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (479, 'salary_payment', 'Salary Payment', 'دفع المرتبات', 'Paiement du salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (480, 'payroll_summary', 'Payroll Summary', 'ملخص الرواتب', 'Résumé de la paie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (481, 'academic', 'Academic', 'أكاديمي', 'Académique');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (482, 'control_classes', 'Control Classes', 'فئات التحكم', 'Contrôle de niveau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (483, 'assign_class_teacher', 'Assign Class Teacher', 'تعيين معلم الصف', 'Attribuer un enseignant de classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (484, 'class_assign', 'Class Assign', 'تعيين فئة', 'Affectation de classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (485, 'assign', 'Assign', 'تعيين', 'Attribuer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (486, 'promotion', 'Promotion', 'ترقية وظيفية', 'Promotion');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (487, 'attachments_book', 'Attachments Book', 'كتاب المرفقات', 'Livre des pièces jointes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (488, 'upload_content', 'Upload Content', 'تحميل المحتوى', 'Télécharger le contenu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (489, 'attachment_type', 'Attachment Type', 'نوع المرفق', 'Type de pièce jointe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (490, 'exam_master', 'Exam Master', 'الامتحان ماجستير', 'Maître d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (491, 'exam_hall', 'Exam Hall', 'قاعة الامتحان', 'Salle d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (492, 'mark_entries', 'Mark Entries', 'إدخالات مارك', 'Marquer les entrées');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (493, 'tabulation_sheet', 'Tabulation Sheet', 'ورقة الجدولة', 'Feuille de tabulation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (494, 'supervision', 'Supervision', 'إشراف', 'Supervision');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (495, 'hostel_master', 'Hostel Master', 'نزل ماستر', 'Hostel Master');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (496, 'hostel_room', 'Hostel Room', 'غرفة نزل', 'Chambre d\'auberge');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (497, 'allocation_report', 'Allocation Report', 'تقرير التخصيص', 'Rapport d\'allocation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (498, 'route_master', 'Route Master', 'سيد الطريق', 'Route Master');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (499, 'vehicle_master', 'Vehicle Master', 'سيد السيارة', 'Véhicule maître');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (500, 'stoppage', 'Stoppage', 'إضراب', 'Arrêt');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (501, 'assign_vehicle', 'Assign Vehicle', 'تخصيص مركبة', 'Assigner un véhicule');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (502, 'reports', 'Reports', 'تقارير', 'Rapports');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (503, 'books_entry', 'Books Entry', 'دخول الكتب', 'Entrée de livres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (504, 'event_type', 'Event Type', 'نوع الحدث', 'Event Type');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (505, 'add_events', 'Add Events', 'إضافة أحداث', 'Ajouter des événements');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (506, 'student_accounting', 'Student Accounting', 'محاسبة الطلاب', 'Comptabilité des étudiants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (507, 'create_single_invoice', 'Create Single Invoice', 'إنشاء فاتورة واحدة', 'Créer une facture unique');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (508, 'create_multi_invoice', 'Create Multi Invoice', 'إنشاء متعدد الفاتورة', 'Créer une facture multiple');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (509, 'summary_report', 'Summary Report', 'تقرير ملخص', 'Rapport sommaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (510, 'office_accounting', 'Office Accounting', 'محاسبة المكتب', 'Comptabilité de bureau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (511, 'under_group', 'Under Group', 'تحت المجموعة', 'Sous groupe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (512, 'bank_account', 'Bank Account', 'حساب البنك', 'Compte bancaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (513, 'ledger_account', 'Ledger Account', 'حساب دفتر الأستاذ', 'Compte général');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (514, 'create_voucher', 'Create Voucher', 'إنشاء قسيمة', 'Créer votre bon');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (515, 'day_book', 'Day Book', 'كتاب اليوم', 'Livre de jour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (516, 'cash_book', 'Cash Book', 'كتاب النقدية', 'Livre de caisse');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (517, 'bank_book', 'Bank Book', 'كتاب البنك', 'Livret de banque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (518, 'ledger_book', 'Ledger Book', 'دفتر الأستاذ', 'Livre de grand livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (519, 'trial_balance', 'Trial Balance', 'ميزان المراجعة', 'Balance de vérification');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (520, 'settings', 'Settings', 'الإعدادات', 'Réglages');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (521, 'sms_settings', 'Sms Settings', 'إعدادات الرسائل القصيرة', 'Paramètres Sms');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (522, 'cash_book_of', 'Cash Book Of', 'كتاب النقدية من', 'Livre de caisse de');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (523, 'by_cash', 'By Cash', 'نقدا', 'En espèces');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (524, 'by_bank', 'By Bank', 'عن طريق البنك', 'Par banque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (525, 'total_strength', 'Total Strength', 'القوة الكلية', 'Force totale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (526, 'teachers', 'Teachers', 'معلمون', 'Enseignants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (527, 'student_quantity', 'Student Quantity', 'كمية الطالب', 'Quantité d\'étudiant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (528, 'voucher', 'Voucher', 'قسيمة', 'Bon');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (529, 'total_number', 'Total Number', 'মোট সংখ্যা', 'Nombre total');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (530, 'total_route', 'Total Route', 'الطريق الإجمالي', 'Total Route');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (531, 'total_room', 'Total Room', 'مجموع الغرفة', 'Chambre totale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (532, 'amount', 'Amount', 'كمية', 'Montant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (533, 'branch_dashboard', 'Branch Dashboard', 'لوحة تحكم الفرع', 'Tableau de bord de branche');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (534, 'branch_list', 'Branch List', 'قائمة الفرع', 'Liste de branche');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (535, 'create_branch', 'Create Branch', 'إنشاء فرع', 'Créer une branche');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (536, 'branch_name', 'Branch Name', 'اسم الفرع', 'Nom de la filiale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (537, 'school_name', 'School Name', 'اسم المدرسة', 'Nom de l\'école');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (538, 'mobile_no', 'Mobile No', 'رقم الموبايل', 'Mobile No');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (539, 'symbol', 'Symbol', 'رمز', 'symbole');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (540, 'city', 'City', 'مدينة', 'Ville');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (541, 'academic_year', 'Academic Year', 'السنة الأكاديمية', 'Année académique');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (542, 'select_branch_first', 'First Select The Branch', 'أولا اختر الفرع', 'D\'abord, sélectionnez la branche');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (543, 'select_class_first', 'Select Class First', 'اختر الفئة الأولى', 'Sélectionnez la classe d\'abord');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (544, 'select_country', 'Select Country', 'حدد الدولة', 'Choisissez le pays');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (545, 'mother_tongue', 'Mother Tongue', 'اللغة الأم', 'Langue maternelle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (546, 'caste', 'Caste', 'الطائفة', 'Caste');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (547, 'present_address', 'Present Address', 'العنوان الحالي', 'Adresse actuelle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (548, 'permanent_address', 'Permanent Address', 'العنوان الثابت', 'Permanent Address');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (549, 'profile_picture', 'Profile Picture', 'الصوره الشخصيه', 'Image de profil');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (550, 'login_details', 'Login Details', 'تفاصيل تسجيل الدخول', 'détails de connexion');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (551, 'retype_password', 'Retype Password', 'أعد إدخال كلمة السر', 'Retaper le mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (552, 'occupation', 'Occupation', 'الاحتلال', 'Ocupación');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (553, 'income', 'Income', 'الإيرادات', 'Ingresos');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (554, 'education', 'Education', 'التعليم', 'Éducation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (555, 'first_select_the_route', 'First Select The Route', 'أولا اختر الطريق', 'Sélectionnez d\'abord l\'itinéraire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (556, 'hostel_details', 'Hostel Details', 'تفاصيل النزل', 'Détails de l\'hôtel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (557, 'first_select_the_hostel', 'First Select The Hostel', 'প্রথম ছাত্রাবাস নির্বাচন', 'd\'abord sélectionner l\'hôtel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (558, 'previous_school_details', 'Previous School Details', 'تفاصيل المدرسة السابقة', 'Privilege School Détails');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (559, 'book_name', 'Book Name', 'اسم الكتاب', 'Nom du livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (560, 'select_ground', 'Select Ground', 'اختر الأرض', 'sélectionnez Ground');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (561, 'import', 'Import', 'استيراد', 'Importation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (562, 'add_student_category', 'Add Student Category', 'إضافة فئة الطالب', 'Ajouter une catégorie d\'étudiant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (563, 'id', 'Id', '', 'Id');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (564, 'edit_category', 'Edit Category', 'تحرير الفئة', 'Modifier la catégorie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (565, 'deactivate_account', 'Deactivate Account', 'تعطيل الحساب', 'Désactiver le compte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (566, 'all_sections', 'All Sections', 'كل الأقسام', 'toutes les filières');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (567, 'authentication_activate', 'Authentication Activate', 'تفعيل المصادقة', 'Authentification Activer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (568, 'department', 'Department', ' قسم، أقسام', 'département');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (569, 'salary_grades', 'Salary Grades', 'راتب', 'Note salariale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (570, 'overtime', 'Overtime Rate (Per Hour)', 'معدل العمل الإضافي (لكل ساعة)', 'taux des heures supplémentaires (à l\'heure)');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (571, 'salary_grade', 'Salary Grade', 'راتب', 'Note salariale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (572, 'payable_type', 'Payable Type', 'نوع الدفع', 'Payable Type');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (573, 'edit_type', 'Edit Type', 'تحرير النوع', 'Τύπος επεξεργασίας');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (574, 'role', 'Role', 'وظيفة', 'Rôle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (575, 'remuneration_info_for', 'Remuneration Info For', 'الأجور معلومات عن', 'Information de rémunération pour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (576, 'salary_paid', 'Salary Paid', 'الراتب المدفوع', 'Salaire payé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (577, 'salary_unpaid', 'Salary Unpaid', 'الراتب غير مدفوع', 'Salaire impayé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (578, 'pay_now', 'Pay Now', 'ادفع الآن', 'Payez maintenant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (579, 'employee_role', 'Employee Role', 'دور الموظف', 'Rôle de l\'employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (580, 'create_at', 'Create At', 'خلق في', 'Créer à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (581, 'select_employee', 'Select Employee', 'اختر الموظف', 'Sélectionnez un employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (582, 'review', 'Review', 'إعادة النظر', 'revisión');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (583, 'reviewed_by', 'Reviewed By', 'تمت مراجعته من قبل', 'Revu par');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (584, 'submitted_by', 'Submitted By', 'المقدمة من قبل', 'Proposé par');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (585, 'employee_type', 'Employee Type', 'نوع موظف', 'Type d\'employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (586, 'approved', 'Approved', 'وافق', 'Approuvé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (587, 'unreviewed', 'Unreviewed', 'غير مراجع', 'Non revu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (588, 'creation_date', 'Creation Date', 'تاريخ الإنشاء', 'Creation Date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (589, 'no_information_available', 'No Information Available', 'لا توجد معلومات متاحة', 'Pas d\'information disponible');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (590, 'continue_to_payment', 'Continue To Payment', 'مواصلة الدفع', 'Continuer au paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (591, 'overtime_total_hour', 'Overtime Total Hour', 'الساعة الاجمالية', 'Heures totales supplémentaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (592, 'overtime_amount', 'Overtime Amount', 'مبلغ العمل الإضافي', 'Heures supplémentaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (593, 'remarks', 'Remarks', 'تعليق', 'Remarque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (594, 'view', 'View', 'رأي', 'Vue');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (595, 'leave_appeal', 'Leave Appeal', 'اترك الاستئناف', 'Laisser appel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (596, 'create_leave', 'Create Leave', 'خلق إجازة', 'Créer un congé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (597, 'user_role', 'User Role', 'دور المستخدم', 'Rôle de l\'utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (598, 'date_of_start', 'Date Of Start', 'تاريخ البدء', 'Date de début');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (599, 'date_of_end', 'Date Of End', 'تاريخ النهاية', 'Date de fin');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (600, 'winner', 'Winner', 'الفائز', 'Gagnantविजेता');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (601, 'select_user', 'Select User', 'اختر المستخدم', 'Sélectionnez un utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (602, 'create_class', 'Create Class', 'إنشاء فصل دراسي', 'Créer un niveau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (603, 'class_teacher_allocation', 'Class Teacher Allocation', 'تخصيص معلم الصف', 'Affectation des enseignants de classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (604, 'class_teacher', 'Class Teacher', 'معلم الصف', 'Professeur de classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (605, 'create_subject', 'Create Subject', 'إنشاء موضوع', 'Créer un sujet');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (606, 'select_multiple_subject', 'Select Multiple Subject', 'حدد موضوعًا متعددًا', 'Sélectionnez plusieurs sujets');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (607, 'teacher_assign', 'Teacher Assign', 'تعيين المعلم', 'Affectation des enseignants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (608, 'teacher_assign_list', 'Teacher Assign List', 'قائمة تعيين المعلم', 'Liste d\'affectation des enseignants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (609, 'select_department_first', 'Select Department First', 'حدد القسم أولاً', 'Sélectionnez d\'abord le département');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (610, 'create_book', 'Create Book', 'إنشاء كتاب', 'Créer un livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (611, 'book_title', 'Book Title', 'عنوان كتاب', 'Titre de livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (612, 'cover', 'Cover', 'التغطية', 'Couverture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (613, 'edition', 'Edition', 'الإصدار', 'Édition');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (614, 'isbn_no', 'ISBN No', 'رقم ISBN', 'ISBN Non');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (615, 'purchase_date', 'Purchase Date', 'تاريخ الشراء', 'Purchase Date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (616, 'cover_image', 'Cover Image', 'صورة الغلاف', 'Cover Image');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (617, 'book_issue', 'Book Issue', 'إصدار الكتاب', 'Numéro de livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (618, 'date_of_issue', 'Date Of Issue', 'تاريخ المسألة', 'Date d&#39;Emission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (619, 'date_of_expiry', 'Date Of Expiry', 'تاريخ الانتهاء', 'Date d\'expiration');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (620, 'select_category_first', 'Select Category First', 'حدد الفئة الأولى', 'Sélectionnez d\'abord la catégorie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (621, 'type_name', 'Type Name', 'أكتب اسم', 'Nom du type');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (622, 'type_list', 'Type List', 'قائمة الأنواع', 'Liste des types');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (623, 'icon', 'Icon', 'أيقونة', 'Icône');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (624, 'event_list', 'Event List', 'قائمة الأحداث', 'Liste des événements');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (625, 'create_event', 'Create Event', 'انشاء حدث', 'Créer un évènement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (626, 'type', 'Type', 'نوع', 'Type');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (627, 'audience', 'Audience', 'الجمهور', 'Audience');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (628, 'created_by', 'Created By', 'انشأ من قبل', 'Créé par');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (629, 'publish', 'Publish', 'ينشر', 'Publier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (630, 'everybody', 'Everybody', 'الجميع', 'Tout le monde');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (631, 'selected_class', 'Selected Class', 'فئة مختارة', 'Classe sélectionnée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (632, 'selected_section', 'Selected Section', 'القسم المختار', 'Filière sélectionnée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (633, 'information_has_been_updated_successfully', 'Information Has Been Updated Successfully', 'تم تحديث المعلومات بنجاح', 'Les informations ont été mises à jour avec succès');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (634, 'create_invoice', 'Create Invoice', 'إنشاء فاتورة', 'Créer une facture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (635, 'invoice_entry', 'Invoice Entry', 'إدخال الفاتورة', 'Saisie de facture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (636, 'quick_payment', 'Quick Payment', 'دفع سريع', 'Paiement rapide');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (637, 'write_your_remarks', 'Write Your Remarks', 'اكتب ملاحظاتك', 'Écrivez vos remarques');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (638, 'reset', 'Reset', 'إعادة تعيين', 'Réinitialiser');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (639, 'fees_payment_history', 'Fees Payment History', 'تاريخ دفع الرسوم', 'Historique des paiements');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (640, 'fees_summary_report', 'Fees Summary Report', 'تقرير ملخص الرسوم', 'Rapport sommaire des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (641, 'add_account_group', 'Add Account Group', 'إضافة مجموعة حساب', 'Ajouter un groupe de comptes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (642, 'account_group', 'Account Group', 'جماعة حساب', 'Compte de groupe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (643, 'account_group_list', 'Account Group List', 'قائمة مجموعة الحساب', 'Liste des groupes de comptes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (644, 'mailbox', 'Mailbox', 'صندوق بريد', 'Boites aux lettres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (645, 'refresh_mail', 'Refresh Mail', 'تحديث البريد', 'Refresh Mail');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (646, 'sender', 'Sender', 'مرسل', 'expéditeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (647, 'general_settings', 'General Settings', 'الاعدادات العامة', 'réglages généraux');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (648, 'institute_name', 'Institute Name', 'اسم المعهد', 'Nom de l&#39;Institut');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (649, 'institution_code', 'Institution Code', 'رمز المؤسسة', 'Institution Code');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (650, 'sms_service_provider', 'Sms Service Provider', 'مزود خدمة الرسائل القصيرة', 'Fournisseur de services SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (651, 'footer_text', 'Footer Text', 'نص التذييل', 'Texte de pied de page');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (652, 'payment_control', 'Payment Control', 'مراقبة الدفع', 'Contrôle des paiements');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (653, 'sms_config', 'Sms Config', 'تكوين الرسائل القصيرة', 'Config Sms');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (654, 'sms_triggers', 'Sms Triggers', 'مشغلات الرسائل القصيرة', 'Déclencheurs SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (655, 'authentication_token', 'Authentication Token', 'رمز المصادقة', 'Jeton d\'authentification');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (656, 'sender_number', 'Sender Number', 'رقم المرسل', 'Numéro d\'expéditeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (657, 'username', 'Username', 'اسم المستخدم', 'Nom d\'utilisateur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (658, 'api_key', 'Api Key', 'مفتاح API', 'Clé API');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (659, 'authkey', 'Authkey', 'Authkey', 'Authkey');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (660, 'sender_id', 'Sender Id', 'معرف الإرسال', 'Identifiant de l\'expéditeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (661, 'sender_name', 'Sender Name', 'اسم المرسل', 'Nom de l\'expéditeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (662, 'hash_key', 'Hash Key', 'مفتاح التجزئة', 'Touche dièse');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (663, 'notify_enable', 'Notify Enable', 'إعلام تمكين', 'Notify Enable');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (664, 'exam_attendance', 'Exam Attendance', 'حضور الامتحان', 'Participation aux examens');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (665, 'exam_results', 'Exam Results', 'نتائج الامتحانات', 'Résultats d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (666, 'email_config', 'Email Config', 'تكوين البريد الإلكتروني', 'Email Config');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (667, 'email_triggers', 'Email Triggers', 'مشغلات البريد الإلكتروني', 'Déclencheurs de messagerie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (668, 'account_registered', 'Account Registered', 'تم تسجيل الحساب', 'Compte enregistré');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (669, 'forgot_password', 'Forgot Password', 'هل نسيت كلمة المرور', 'Mot de passe oublié');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (670, 'new_message_received', 'New Message Received', 'تم تلقي رسالة جديدة', 'Nouveau message reçu');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (671, 'payslip_generated', 'Payslip Generated', 'تم إنشاء Payslip', 'Fiche de paie générée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (672, 'leave_approve', 'Leave Approve', 'اترك الموافقة', 'Laisser approuver');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (673, 'leave_reject', 'Leave Reject', 'اترك رفض', 'Laisser rejeter');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (674, 'advance_salary_approve', 'Leave Reject', 'اترك رفض', 'Laisser rejeter');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (675, 'advance_salary_reject', 'Advance Salary Reject', 'رفض الراتب المسبق', 'Rejet de salaire anticipé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (676, 'add_session', 'Add Session', 'إضافة جلسة', 'Ajouter une session');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (677, 'session', 'Session', 'جلسة', 'Session');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (678, 'created_at', 'Created At', 'أنشئت في', 'Créé à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (679, 'sessions', 'Sessions', 'الجلسات', 'Sessions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (680, 'flag', 'Flag', 'العلم', 'Drapeau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (681, 'stats', 'Stats', 'احصائيات', 'Statistiques');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (682, 'updated_at', 'Updated At', 'تم التحديث في', 'Mis à jour à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (683, 'flag_icon', 'Flag Icon', 'رمز العلم', 'Icône de drapeau');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (684, 'password_restoration', 'Password Restoration', 'استعادة كلمة المرور', 'Restauration du mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (685, 'forgot', 'Forgot', 'نسيت', 'Oublié');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (686, 'back_to_login', 'Back To Login', 'العودة لتسجيل الدخول', 'Retour connexion');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (687, 'database_list', 'Database List', 'قائمة قاعدة البيانات', 'Liste des bases de données');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (688, 'create_backup', 'Create Backup', 'انشئ نسخة احتياطية', 'Créer une sauvegarde');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (689, 'backup', 'Backup', 'دعم', 'Sauvegarde');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (690, 'backup_size', 'Backup Size', 'حجم النسخ الاحتياطي', 'Taille de sauvegarde');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (691, 'file_upload', 'File Upload', 'تحميل الملف', 'Téléchargement de fichiers');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (692, 'parents_details', 'Parents Details', 'تفاصيل الوالدين', 'Détails des parents');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (693, 'social_links', 'Social Links', 'روابط اجتماعية', 'Liens sociaux');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (694, 'create_hostel', 'Create Hostel', 'إنشاء نزل', 'Créer une auberge');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (695, 'allocation_list', 'Allocation List', 'قائمة التخصيص', 'Allocation List');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (696, 'payslip_history', 'Payslip History', 'سجل الدفع', 'Historique des fiches de paie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (697, 'my_attendance_overview', 'My Attendance Overview', 'نظرة عامة على الحضور', 'Présentation de My Attendance');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (698, 'total_present', 'Total Present', 'المجموع الحالي', 'Total présent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (699, 'total_absent', 'Total Absent', 'المجموع الكلي', 'Total Absent');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (700, 'total_late', 'Total Late', 'المجموع المتأخر', 'Total en retard');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (701, 'class_teacher_list', 'Class Teacher List', 'قائمة مدرس الفصل', 'Liste des enseignants de classe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (702, 'section_control', 'Section Control', 'التحكم بالقسم', 'Filière côntrole');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (703, 'capacity ', 'Capacity', 'سعة', 'Capacité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (704, 'request', 'Request', 'طلب', 'Demande');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (705, 'salary_year', 'Salary Year', 'سنة الراتب', 'Année de salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (706, 'create_attachments', 'Create Attachments', 'إنشاء المرفقات', 'Créer des pièces jointes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (707, 'publish_date', 'Publish Date', 'تاريخ النشر', 'Publish Date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (708, 'attachment_file', 'Attachment File', 'ملف المرفق', 'Fichier joint');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (709, 'age', 'Age', 'عمر', 'Âge');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (710, 'student_profile', 'Student Profile', 'الملف الشخصي للطالب', 'Profil étudiant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (711, 'authentication', 'Authentication', 'المصادقة', 'Authentification');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (712, 'parent_information', 'Parent Information', 'معلومات الوالدين', 'Parent Information');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (713, 'full_marks', 'Full Marks', 'علامات كاملة', 'La totalité des points');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (714, 'passing_marks', 'Passing Marks', 'علامات النجاح', 'Marques de passage');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (715, 'highest_marks', 'Highest Marks', 'أعلى العلامات', 'Marques les plus élevées');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (716, 'unknown', 'Unknown', 'مجهول', 'Inconnue');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (717, 'unpublish', 'Unpublish', 'غير منشور', 'Annuler la publication');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (718, 'login_authentication_deactivate', 'Login Authentication Deactivate', 'إلغاء تنشيط مصادقة تسجيل الدخول', 'Authentification de connexion désactivée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (719, 'employee_profile', 'Employee Profile', 'ملف تعريف الموظف', 'Profil d\'employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (720, 'employee_details', 'Employee Details', 'تفاصيل الموظف', 'Détails de l\'employé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (721, 'salary_transaction', 'Salary Transaction', 'معاملة الراتب', 'Transaction salariale');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (722, 'documents', 'Documents', 'مستندات', 'Documents');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (723, 'actions', 'Actions', 'أجراءات', 'Actions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (724, 'activity', 'Activity', 'نشاط', 'Activité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (725, 'department_list', 'Department List', 'قائمة الأقسام', 'Liste des départements');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (726, 'manage_employee_salary', 'Manage Employee Salary', 'إدارة راتب الموظف', 'Gérer le salaire des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (727, 'the_configuration_has_been_updated', 'The Configuration Has Been Updated', 'تم تحديث التكوين', 'La configuration a été mise à jour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (728, 'add', 'Add', 'أضف', 'Ajouter');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (729, 'create_exam', 'Create Exam', 'إنشاء امتحان', 'Créer un examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (730, 'term', 'Term', 'مصطلح', 'Terme');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (731, 'add_term', 'Add Term', 'إضافة مصطلح', 'Ajouter un terme');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (732, 'create_grade', 'Create Grade', 'إنشاء تقدير', 'Créer une note');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (733, 'mark_starting', 'Mark Starting', 'علامة البداية', 'Mark Starting');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (734, 'mark_until', 'Mark Until', 'ضع علامة حتى', 'Marquer jusqu\'à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (735, 'room_list', 'Room List', 'قائمة غرفة', 'Liste des chambres');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (736, 'room', 'Room', 'غرفة', 'Chambre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (737, 'route_list', 'Route List', 'قائمة المسار', 'Liste des itinéraires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (738, 'create_route', 'Create Route', 'إنشاء طريق', 'Créer un itinéraire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (739, 'vehicle_list', 'Vehicle List', 'قائمة المركبات', 'Liste des véhicules');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (740, 'create_vehicle', 'Create Vehicle', 'إنشاء مركبة', 'Créer un véhicule');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (741, 'stoppage_list', 'Stoppage List', 'قائمة التوقف', 'Liste des arrêts');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (742, 'create_stoppage', 'Create Stoppage', 'إنشاء توقف', 'Créer un arrêt');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (743, 'stop_time', 'Stop Time', 'وقت التوقف', 'Temps d\'arrêt');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (744, 'employee_attendance', 'Employee Attendance', 'حضور الموظف', 'Présence des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (745, 'attendance_report', 'Attendance Report', 'حضور الموظف', 'Présence des employés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (746, 'opening_balance', 'Opening Balance', 'الرصيد الافتتاحي', 'Solde d\'ouverture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (747, 'add_opening_balance', 'Add Opening Balance', 'إضافة رصيد افتتاحي', 'Ajouter un solde d\'ouverture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (748, 'credit', 'Credit', 'ائتمان', 'Crédit');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (749, 'debit', 'Debit', 'مدين', 'Débit');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (750, 'opening_balance_list', 'Opening Balance List', 'قائمة الرصيد الافتتاحي', 'liste des soldes d\'ouverture');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (751, 'voucher_list', 'Voucher List', 'قائمة القسائم', 'Liste des bons');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (752, 'voucher_head', 'Voucher Head', 'رئيس قسيمة', 'Tête de bon');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (753, 'payment_method', 'Payment Method', 'طريقة الدفع او السداد', 'Mode de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (754, 'credit_ledger_account', 'Credit Ledger Account', 'حساب دفتر الأستاذ الائتماني', 'Compte de crédit');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (755, 'debit_ledger_account', 'Debit Ledger Account', 'حساب دفتر الأستاذ المدين', 'Compte du livre de débit');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (756, 'voucher_no', 'Voucher No', 'رقم القسيمة', 'Numéro de bon');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (757, 'balance', 'Balance', 'توازن', 'Équilibre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (758, 'event_details', 'Event Details', 'تفاصيل الحدث', 'Détails de l\'évènement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (759, 'welcome_to', 'Welcome To', 'مرحبا بك في', 'Bienvenue à');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (760, 'report_card', 'Report Card', 'بطاقة تقرير', 'Bulletin scolaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (761, 'online_pay', 'Online Pay', 'الدفع عبر الإنترنت', 'Paiement en ligne');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (762, 'annual_fees_summary', 'Annual Fees Summary', 'ملخص الرسوم السنوية', 'Résumé des frais annuels');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (763, 'my_children', 'My Children', 'أطفالي', 'Mes enfants');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (764, 'assigned', 'Assigned', 'تعيين', 'Attribué');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (765, 'confirm_password', 'Confirm Password', 'تأكيد كلمة المرور', 'Confirmez le mot de passe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (766, 'searching_results', 'Searching Results', 'نتائج البحث', 'Résultats de la recherche');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (767, 'information_has_been_saved_successfully', 'Information Has Been Saved Successfully', 'تم حفظ المعلومات بنجاح', 'Les informations ont été enregistrées avec succès');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (768, 'information_deleted', 'The information has been successfully deleted', 'تم حذف المعلومات بنجاح', 'L\'information a été supprimée avec succès');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (769, 'deleted_note', '*Note : This data will be permanently deleted', '* ملاحظة: سيتم حذف هذه البيانات نهائيًا', '* Remarque: ces données seront définitivement supprimées.');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (770, 'are_you_sure', 'Are You Sure?', 'هل أنت واثق؟', 'Êtes-vous sûr?');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (771, 'delete_this_information', 'Do You Want To Delete This Information?', 'هل تريد حذف هذه المعلومات؟', 'Voulez-vous supprimer cette information?');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (772, 'yes_continue', 'Yes, Continue', 'نعم ، استمر', 'Oui, continuez');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (773, 'deleted', 'Deleted', 'تم الحذف', 'Effacé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (774, 'collect', 'Collect', 'تجميع', 'Collecte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (775, 'school_setting', 'School Setting', 'إعداد المدرسة', 'Milieu scolaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (776, 'set', 'Set', 'جلس', 'Ensemble');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (777, 'quick_view', 'Quick View', 'نظرة سريعة', 'Aperçu rapide');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (778, 'due_fees_invoice', 'Due Fees Invoice', 'فاتورة رسوم مستحقة', 'Facture due');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (779, 'my_application', 'My Application', 'طلبي', 'Mon application');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (780, 'manage_application', 'Manage Application', 'إدارة الطلب', 'Gérer l\'application');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (781, 'leave', 'Leave', 'غادر', 'Laisser');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (782, 'live_class_rooms', 'Live Class Rooms', 'غرف الصف المباشر', 'Salles de cours en direct');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (783, 'homework', 'Homework', 'واجب منزلي', 'Devoirs');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (784, 'evaluation_report', 'Evaluation Report', 'تقرير التقييم', 'Rapport d\'évaluation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (785, 'exam_term', 'Exam Term', 'مصطلح الامتحان', 'Durée de l\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (786, 'distribution', 'Distribution', 'توزيع', 'Distribution');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (787, 'exam_setup', 'Exam Setup', 'إعداد الامتحان', 'Configuration de l\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (788, 'sms', 'Sms', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (789, 'fees_type', 'Fees Type', 'نوع الرسوم', 'Type de frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (790, 'fees_group', 'Fees Group', 'مجموعة الرسوم', 'Groupe de frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (791, 'fine_setup', 'Fine Setup', 'الإعداد الجيد', 'Configuration fine');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (792, 'fees_reminder', 'Fees Reminder', 'تذكير بالرسوم', 'Rappel des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (793, 'new_deposit', 'New Deposit', 'وديعة جديدة', 'Nouveau dépôt');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (794, 'new_expense', 'New Expense', 'نفقة جديدة', 'Nouvelle dépense');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (795, 'all_transactions', 'All Transactions', 'كل الحركات المالية', 'toutes transactions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (796, 'head', 'Head', 'رئيس', 'Tête');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (797, 'fees_reports', 'Fees Reports', 'تقارير الرسوم', 'Rapports sur les frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (798, 'fees_report', 'Fees Report', 'تقرير الرسوم', 'Rapport sur les frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (799, 'receipts_report', 'Receipts Report', 'تقرير الإيصالات', 'Rapport sur les reçus');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (800, 'due_fees_report', 'Due Fees Report', 'تقرير الرسوم المستحقة', 'Rapport sur les frais dus');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (801, 'fine_report', 'Fine Report', 'تقرير جيد', 'Beau rapport');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (802, 'financial_reports', 'Financial Reports', 'تقارير مالية', 'Rapports financiers');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (803, 'statement', 'Statement', 'بيان', 'Déclaration');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (804, 'repots', 'Repots', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (805, 'expense', 'Expense', 'مصروف', 'Frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (806, 'transitions', 'Transitions', 'الانتقالات', 'Transitions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (807, 'sheet', 'Sheet', 'ورقة', 'Feuille');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (808, 'income_vs_expense', 'Income Vs Expense', 'الدخل مقابل المصاريف', 'Revenu contre dépenses');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (809, 'attendance_reports', 'Attendance Reports', 'تقارير الحضور', 'Rapports de présence');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (810, 'examination', 'Examination', 'فحص', 'Examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (811, 'school_settings', 'School Settings', 'إعدادات المدرسة', 'Paramètre d\'UCA');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (812, 'role_permission', 'Role Permission', 'إذن الدور', 'Autorisation de rôle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (813, 'cron_job', 'Cron Job', 'وظيفة كرون', 'Tâche planifiée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (814, 'custom_field', 'Custom Field', 'حقل مخصص', 'Champ personnalisé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (815, 'enter_valid_email', 'Enter Valid Email', 'أدخل بريدًا إلكترونيًا صالحًا', 'Entrez une adresse email valide');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (816, 'lessons', 'Lessons', 'الدروس', 'Cours');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (817, 'live_class', 'Live Class', 'فئة حية', 'Cours en direct');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (818, 'sl', 'Sl', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (819, 'meeting_id', 'Meeting ID', 'فئة حية', 'Cours en direct');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (820, 'start_time', 'Start Time', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (821, 'end_time', 'End Time', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (822, 'zoom_meeting_id', 'Zoom Meeting Id', 'تكبير / تصغير معرف الاجتماع', 'Zoom ID de réunion');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (823, 'zoom_meeting_password', 'Zoom Meeting Password', 'تكبير كلمة مرور الاجتماع', 'Zoom sur le mot de passe de la réunion');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (824, 'time_slot', 'Time Slot', 'فسحة زمنية', 'Créneau horaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (825, 'send_notification_sms', 'Send Notification Sms', 'إرسال رسالة إعلام', 'Envoyer des SMS de notification');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (826, 'host', 'Host', 'مضيف', 'Hôte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (827, 'school', 'School', 'مدرسة', 'École');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (828, 'accounting_links', 'Accounting Links', 'روابط المحاسبة', 'Liens comptables');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (829, 'applicant', 'Applicant', 'طالب وظيفة', 'Demandeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (830, 'apply_date', 'Apply Date', 'تاريخ تطبيق', 'Date d\'application');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (831, 'add_leave', 'Add Leave', 'أضف إجازة', 'Ajouter un congé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (832, 'leave_date', 'Leave Date', 'تاريخ مغادرة', 'Date de départ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (833, 'attachment', 'Attachment', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (834, 'comments', 'Comments', 'تعليقات', 'commentaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (835, 'staff_id', 'Staff Id', 'معرف الموظفين', 'Identifiant du personnel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (836, 'income_vs_expense_of', 'Income Vs Expense Of', 'دخل مقابل حساب', 'Revenu contre dépenses de');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (837, 'designation_name', 'Designation Name', 'اسم التعيين', 'Nom de la désignation');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (838, 'already_taken', 'This %s already exists.', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (839, 'department_name', 'Department Name', 'اسم القسم', 'Nom du département');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (840, 'date_of_birth', 'Date Of Birth', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (841, 'bulk_delete', 'Bulk Delete', 'حذف مجمّع', 'Suppression groupée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (842, 'guardian_name', 'Guardian Name', 'اسم الوصي', 'Nom du gardien');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (843, 'fees_progress', 'Fees Progress', 'رسوم التقدم', 'Progression des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (844, 'evaluate', 'Evaluate', 'تقييم', 'Évaluer');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (845, 'date_of_homework', 'Date Of Homework', 'تاريخ الواجب المنزلي', 'Date des devoirs');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (846, 'date_of_submission', 'Date Of Submission', 'تاريخ التقديم', 'Date de soumission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (847, 'student_fees_report', 'Student Fees Report', 'تقرير رسوم الطالب', 'Rapport sur les frais de scolarité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (848, 'student_fees_reports', 'Student Fees Reports', 'تقارير رسوم الطلاب', 'Rapports sur les frais de scolarité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (849, 'due_date', 'Due Date', 'تاريخ الاستحقاق', 'Due Date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (850, 'payment_date', 'Payment Date', 'موعد الدفع', 'Date de paiement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (851, 'payment_via', 'Payment Via', 'الدفع عن طريق', 'Paiement via');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (852, 'generate', 'Generate', 'انشاء', 'produire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (853, 'print_date', 'Print Date', 'تاريخ الطباعة', 'Print Date');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (854, 'bulk_sms_and_email', 'Bulk Sms And Email', 'الرسائل القصيرة والبريد الإلكتروني', 'Sms en vrac et email');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (855, 'campaign_type', 'Campaign Type', 'نوع الحملة', 'Type de campagne');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (856, 'both', 'Both', 'على حد سواء', 'Tous les deux');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (857, 'regular', 'Regular', 'منتظم', 'Ordinaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (858, 'Scheduled', 'Scheduled', 'المقرر', 'Programmé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (859, 'campaign', 'Campaign', 'حملة', 'Campagne');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (860, 'campaign_name', 'Campaign Name', 'اسم الحملة', 'Nom de la campagne');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (861, 'sms_gateway', 'Sms Gateway', 'بوابة الرسائل القصيرة', 'Passerelle SMS');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (862, 'recipients_type', 'Recipients Type', 'نوع المستلمين', 'Type de destinataires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (863, 'recipients_count', 'Recipients Count', 'عدد المستلمين', 'Nombre de destinataires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (864, 'body', 'Body', 'الجسم', 'Corps');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (865, 'guardian_already_exist', 'Guardian Already Exist', 'الوصي موجود بالفعل', 'Guardian existe déjà');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (866, 'guardian', 'Guardian', 'وصي', 'Gardien');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (867, 'mother_name', 'Mother Name', 'اسم الأم', 'Nom de la mère');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (868, 'bank_details', 'Bank Details', 'التفاصيل المصرفية', 'coordonnées bancaires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (869, 'skipped_bank_details', 'Skipped Bank Details', 'تخطي تفاصيل البنك', 'Détails bancaires ignorés');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (870, 'bank', 'Bank', 'مصرف', 'Banque');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (871, 'holder_name', 'Holder Name', 'اسم صاحب التسجيل', 'Nom du titulaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (872, 'bank_branch', 'Bank Branch', 'فرع بنك', 'Agence bancaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (873, 'custom_field_for', 'Custom Field For', 'حقل مخصص لـ', 'Champ personnalisé pour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (874, 'label', 'Label', 'ضع الكلمة المناسبة', 'Label');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (875, 'order', 'Order', 'طلب', 'Ordre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (876, 'online_admission', 'Online Admission', 'القبول عبر الإنترنت', 'Online Admission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (877, 'field_label', 'Field Label', 'تسمية الميدان', 'Étiquette de champ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (878, 'field_type', 'Field Label', 'تسمية الميدان', 'Étiquette de champ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (879, 'default_value', 'Default Value', 'القيمة الافتراضية', 'Valeur par défaut');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (880, 'checked', 'Checked', 'التحقق', 'Vérifié');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (881, 'unchecked', 'Unchecked', 'غير محدد', 'Décoché');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (882, 'roll_number', 'Roll Number', 'رقم اللفة', 'Numéro de rôle');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (883, 'add_rows', 'Add Rows', 'إضافة صفوف', 'Ajouter des lignes');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (884, 'salary', 'Salary', 'راتب', 'Un salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (885, 'basic', 'Basic', 'الأساسي', 'De base');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (886, 'allowance', 'Allowance', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (887, 'deduction', 'Deduction', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (888, 'net', 'Net', 'Net', 'Net');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (889, 'activated_sms_gateway', 'Activated Sms Gateway', 'بوابة الرسائل القصيرة المنشّطة', 'Passerelle Sms activée');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (890, 'account_sid', 'Account Sid', 'حساب Sid', 'Compte Sid');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (891, 'roles', 'Roles', 'الأدوار', 'Les rôles');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (892, 'system_role', 'System Role', 'دور النظام', 'Rôle système');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (893, 'permission', 'Permission', 'الإذن', 'Permission');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (894, 'edit_session', 'Edit Session', 'تحرير الجلسة', 'Edit Session');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (895, 'transactions', 'Transactions', 'المعاملات', 'Transactions');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (896, 'default_account', 'Default Account', 'الحساب الافتراضي', 'Compte par défaut');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (897, 'deposit', 'Deposit', 'الوديعة', 'Dépôt');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (898, 'acccount', 'Acccount', 'حساب', 'Compte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (899, 'role_permission_for', 'Role Permission For', 'إذن دور لـ', 'Autorisation de rôle pour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (900, 'feature', 'Feature', 'خاصية', 'Fonctionnalité');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (901, 'access_denied', 'Access Denied', 'تم الرفض', 'Accès refusé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (902, 'time_start', 'Time Start', 'وقت البدء', 'Heure de début');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (903, 'time_end', 'Time End', 'انتهى الوقت', 'Fin de temps');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (904, 'month_of_salary', 'Month Of Salary', 'شهر الراتب', 'Mois de salaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (905, 'add_documents', 'Add Documents', 'أضف وثائق', 'Ajouter des documents');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (906, 'document_type', 'Document Type', 'نوع الوثيقة', 'Document Type');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (907, 'document', 'Document', 'المستند', 'Document');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (908, 'document_title', 'Document Title', 'عنوان الوثيقة', 'Titre du document');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (909, 'document_category', 'Document Category', 'فئة الوثيقة', 'Catégorie de document');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (910, 'exam_result', 'Exam Result', 'نتيجة الإمتحان', 'Résultat d\'éxamen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (911, 'my_annual_fee_summary', 'My Annual Fee Summary', 'ملخص رسومي السنوي', 'Mon résumé des frais annuels');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (912, 'book_manage', 'Book Manage', 'إدارة الكتاب', 'Book Manage');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (913, 'add_leave_category', 'Add Leave Category', 'إضافة فئة إجازة', 'Ajouter une catégorie de congé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (914, 'edit_leave_category', 'Edit Leave Category', 'تحرير فئة الإجازة', 'Modifier la catégorie de congé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (915, 'staff_role', 'Staff Role', 'دور الموظفين', 'Rôle du personnel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (916, 'edit_assign', 'Edit Assign', 'تحرير تعيين', 'Modifier l\'attribution');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (917, 'view_report', 'View Report', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (918, 'rank_out_of_5', 'Rank Out Of 5', 'مرتبة من 5', 'Classement sur 5');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (919, 'hall_no', 'Hall No', 'القاعة رقم', 'Salle No');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (920, 'no_of_seats', 'No Of Seats', 'عدد المقاعد', 'Pas de sièges');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (921, 'mark_distribution', 'Mark Distribution', 'توزيع مارك', 'Mark Distribution');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (922, 'exam_type', 'Exam Type', 'نوع الامتحان', 'Type d\'examen');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (923, 'marks_and_grade', 'Marks And Grade', 'العلامات والدرجات', 'Marques et grade');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (924, 'min_percentage', 'Min Percentage', 'النسبة المئوية', 'Pourcentage minimal');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (925, 'max_percentage', 'Max Percentage', 'النسبة المئوية القصوى', 'Pourcentage max');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (926, 'cost_per_bed', 'Cost Per Bed', 'تكلفة السرير', 'Coût par lit');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (927, 'add_category', 'Add Category', 'إضافة فئة', 'ajouter une catégorie');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (928, 'category_for', 'Category For', 'التصنيف لـ', 'Catégorie Pour');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (929, 'start_place', 'Start Place', 'ابدأ مكان', 'Start Place');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (930, 'stop_place', 'Stop Place', 'مكان التوقف', 'Stop Place');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (931, 'vehicle', 'Vehicle', 'مركبة', 'Véhicule');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (932, 'select_multiple_vehicle', 'Select Multiple Vehicle', 'حدد مركبة متعددة', 'Sélectionnez plusieurs véhicules');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (933, 'book_details', 'Book Details', 'تفاصيل الكتاب', 'Détails du livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (934, 'issued_by', 'Issued By', 'أصدرت من قبل', 'Délivré par');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (935, 'return_by', 'Return By', 'العودة بواسطة', 'Retour par');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (936, 'group', 'Group', 'مجموعة', 'Groupe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (937, 'individual', 'Individual', 'فرد', 'Individuel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (938, 'recipients', 'Recipients', 'المستلمون', 'Destinataires');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (939, 'group_name', 'Group Name', 'أسم المجموعة', 'Nom de groupe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (940, 'fee_code', 'Fee Code', 'كود الرسوم', 'Fee Code');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (941, 'fine_type', 'Fine Type', 'نوع جيد', 'Type fin');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (942, 'fine_value', 'Fine Value', 'قيمة جيدة', 'Fine Value');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (943, 'late_fee_frequency', 'Late Fee Frequency', 'تردد الرسوم المتأخرة', 'Fréquence des frais de retard');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (944, 'fixed_amount', 'Fixed Amount', 'مبلغ ثابت', 'Montant fixé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (945, 'fixed', 'Fixed', 'ثابت', 'Fixé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (946, 'daily', 'Daily', 'اليومي', 'du quotidien');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (947, 'weekly', 'Weekly', 'أسبوعي', 'Hebdomadaire');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (948, 'monthly', 'Monthly', 'شهريا', 'Mensuel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (949, 'annually', 'Annually', 'سنويا', 'Annuellement');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (950, 'first_select_the_group', 'First Select The Group', 'أولا حدد المجموعة', 'Sélectionnez d\'abord le groupe');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (951, 'percentage', 'Percentage', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (952, 'value', 'Value', 'القيمة', 'Valeur');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (953, 'fee_group', 'Fee Group', 'مجموعة الرسوم', 'Groupe de frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (954, 'due_invoice', 'Due Invoice', 'فاتورة مستحقة', 'Facture due');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (955, 'reminder', 'Reminder', 'تذكير', 'Rappel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (956, 'frequency', 'Frequency', 'تكرر', 'La fréquence');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (957, 'notify', 'Notify', 'أبلغ', 'Notifier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (958, 'before', 'Before', 'قبل', 'Avant');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (959, 'after', 'After', 'بعد', 'Après');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (960, 'number', 'Number', 'رقم', 'Nombre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (961, 'ref_no', 'Ref No', 'مصدر رقم', 'Réf No');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (962, 'pay_via', 'Pay Via', 'ادفع عن طريق', 'Payez via');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (963, 'ref', 'Ref', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (964, 'dr', 'Dr', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (965, 'cr', 'Cr', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (966, 'edit_book', 'Edit Book', 'تحرير كتاب', 'Modifier le livre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (967, 'leaves', 'Leaves', 'اوراق اشجار', 'Feuilles');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (968, 'leave_request', 'Leave Request', 'طلب إجازة', 'Demande de congé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (969, 'this_file_type_is_not_allowed', 'This File Type Is Not Allowed', 'نوع الملف هذا غير مسموح به', 'Ce type de fichier n\'est pas autorisé');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (970, 'error_reading_the_file', 'Error Reading The File', 'خطأ في قراءة الملف', 'Erreur de lecture du fichier');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (971, 'staff', 'Staff', 'العاملين', 'Personnel');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (972, 'waiting', 'Waiting', 'انتظار', 'Attendre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (973, 'live', 'Live', 'حي', 'Vivre');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (974, 'by', 'By', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (975, 'host_live_class', 'Host Live Class', 'استضافة فئة مباشرة', 'Host Live Class');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (976, 'join_live_class', 'Join Live Class', 'انضم إلى Live Class', 'Rejoignez Live Class');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (977, 'system_logo', 'System Logo', 'شعار النظام', 'Logo du système');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (978, 'text_logo', 'Text Logo', 'شعار النص', 'Logo texte');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (979, 'printing_logo', 'Printing Logo', 'شعار الطباعة', 'Printing Logo');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (980, 'expired', 'Expired', 'منتهية الصلاحية', 'Expiré');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (981, 'collect_fees', 'Collect Fees', 'تحصيل الرسوم', 'Percevoir les frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (982, 'fees_code', 'Fees Code', 'كود الرسوم', 'Code des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (983, 'collect_by', 'Collect By', 'اجمع بواسطة', 'Collecter par');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (984, 'fee_payment', 'Fee Payment', 'دفع الرسوم', 'Paiement des frais');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (985, 'write_message', 'Write Message', 'اكتب رسالة', 'Écrire un message');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (986, 'discard', 'Discard', 'تجاهل', 'Jeter');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (987, 'message_sent_successfully', 'Message Sent Successfully', 'تم إرسال الرسالة بنجاح', 'Message envoyé avec succès');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (988, 'visit_home_page', 'Visit Home Page', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (989, 'frontend', 'Frontend', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (990, 'setting', 'Setting', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (991, 'menu', 'Menu', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (992, 'page', 'Page', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (993, 'manage', 'Manage', '', 'Gérer ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (994, 'slider', 'Slider', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (995, 'features', 'Features', '', 'Niveaux dans le homepage');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (996, 'testimonial', 'Testimonial', '', 'Témoignage ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (997, 'service', 'Service', '', 'Pourquoi nous choisir');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (998, 'faq', 'Faq', '', 'F.A.Q');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (999, 'card_management', 'Card Management', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1000, 'id_card', 'Id Card', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1001, 'templete', 'Templete', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1002, 'admit_card', 'Admit Card', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1003, 'certificate', 'Certificate', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1004, 'system_update', 'System Update', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1005, 'url', 'Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1006, 'content', 'Content', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1007, 'banner_photo', 'Banner Photo', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1008, 'meta', 'Meta', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1009, 'keyword', 'Keyword', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1010, 'applicable_user', 'Applicable User', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1011, 'page_layout', 'Page Layout', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1012, 'background', 'Background', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1013, 'image', 'Image', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1014, 'width', 'Width', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1015, 'height', 'Height', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1016, 'signature', 'Signature', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1017, 'website', 'Website', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1018, 'cms', 'Cms', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1019, 'url_alias', 'Url Alias', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1020, 'cms_frontend', 'Cms Frontend', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1021, 'enabled', 'Enabled', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1022, 'receive_email_to', 'Receive Email To', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1023, 'captcha_status', 'Captcha Status', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1024, 'recaptcha_site_key', 'Recaptcha Site Key', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1025, 'recaptcha_secret_key', 'Recaptcha Secret Key', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1026, 'working_hours', 'Working Hours', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1027, 'fav_icon', 'Fav Icon', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1028, 'theme', 'Theme', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1029, 'fax', 'Fax', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1030, 'footer_about_text', 'Footer About Text', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1031, 'copyright_text', 'Copyright Text', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1032, 'facebook_url', 'Facebook Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1033, 'twitter_url', 'Twitter Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1034, 'youtube_url', 'Youtube Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1035, 'google_plus', 'Google Plus', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1036, 'linkedin_url', 'Linkedin Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1037, 'pinterest_url', 'Pinterest Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1038, 'instagram_url', 'Instagram Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1039, 'play', 'Play', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1040, 'video', 'Video', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1041, 'usename', 'Usename', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1042, 'experience_details', 'Experience Details', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1043, 'total_experience', 'Total Experience', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1044, 'class_schedule', 'Class Schedule', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1045, 'cms_default_branch', 'Cms Default Branch', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1046, 'website_page', 'Website Page', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1047, 'welcome', 'Welcome', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1048, 'services', 'Services', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1049, 'call_to_action_section', 'Call To Action Section', '', 'Action sur filière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1050, 'subtitle', 'Subtitle', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1051, 'cta', 'Cta', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1052, 'button_text', 'Button Text', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1053, 'button_url', 'Button Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1054, '_title', ' Title', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1055, 'contact', 'Contact', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1056, 'box_title', 'Box Title', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1057, 'box_description', 'Box Description', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1058, 'box_photo', 'Box Photo', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1059, 'form_title', 'Form Title', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1060, 'submit_button_text', 'Submit Button Text', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1061, 'map_iframe', 'Map Iframe', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1062, 'email_subject', 'Email Subject', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1063, 'prefix', 'Prefix', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1064, 'surname', 'Surname', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1065, 'rank', 'Rank', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1066, 'submit', 'Submit', '', 'Enregistrer ');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1067, 'certificate_name', 'Certificate Name', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1068, 'layout_width', 'Layout Width', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1069, 'layout_height', 'Layout Height', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1070, 'expiry_date', 'Expiry Date', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1071, 'position', 'Position', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1072, 'target_new_window', 'Target New Window', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1073, 'external_url', 'External Url', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1074, 'external_link', 'External Link', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1075, 'sms_notification', 'Sms Notification', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1076, 'scheduled_at', 'Scheduled At', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1077, 'published', 'Published', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1078, 'unpublished_on_website', 'Unpublished On Website', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1079, 'published_on_website', 'Published On Website', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1080, 'no_selection_available', 'No Selection Available', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1081, 'select_for_everyone', 'Select For Everyone', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1082, 'teacher_restricted', 'Teacher Restricted', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1083, 'guardian_relation', 'Guardian Relation', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1084, 'username_prefix', 'Username Prefix', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1085, 'default_password', 'Default Password', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1086, 'parents_profile', 'Parents Profile', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1087, 'childs', 'Childs', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1088, 'page_title', 'Page Title', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1089, 'select_menu', 'Select Menu', '', 'Sélectionnez');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1090, 'meta_keyword', 'Meta Keyword', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1091, 'meta_description', 'Meta Description', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1092, 'evaluation_date', 'Evaluation Date', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1093, 'evaluated_by', 'Evaluated By', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1094, 'complete', 'Complete', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1095, 'incomplete', 'Incomplete', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1096, 'payment_details', 'Payment Details', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1097, 'edit_attachments', 'Edit Attachments', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1098, 'live_classes', 'Live Classes', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1099, 'duration', 'Duration', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1100, 'metting_id', 'Metting Id', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1101, 'set_record', 'Set Record', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1102, 'set_mute_on_start', 'Set Mute On Start', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1103, 'button_text_1', 'Button Text 1', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1104, 'button_url_1', 'Button Url 1', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1105, 'button_text_2', 'Button Text 2', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1106, 'button_url_2', 'Button Url 2', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1107, 'left', 'Left', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1108, 'center', 'Center', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1109, 'right', 'Right', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1110, 'about', 'About', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1111, 'about_photo', 'About Photo', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1112, 'parallax_photo', 'Parallax Photo', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1113, 'decline', 'Decline', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1114, 'edit_grade', 'Edit Grade', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1115, 'mark', 'Mark', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1116, 'hall_room', 'Hall Room', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1117, 'student_promotion', 'Student Promotion', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1118, 'username_has_already_been_used', 'Username Has Already Been Used', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1119, 'fee_collection', 'Fee Collection', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1120, 'not_found_anything', 'Not Found Anything', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1121, 'preloader_backend', 'Preloader Backend', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1122, 'ive_class_method', 'Ive Class Method', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1123, 'live_class_method', 'Live Class Method', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1124, 'api_credential', 'Api Credential', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1125, 'translation_update', 'Translation Update', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1126, ' live_class_reports', ' Live Class Reports', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1127, 'live_class_reports', 'Live Class Reports', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1128, 'all', 'All', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1129, 'student_participation_report', 'Student Participation Report', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1130, 'joining_time', 'Joining Time', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1131, 'gallery', 'Gallery', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1132, 'parent_menu', 'Parent Menu', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1133, 'statistics', 'Statistics', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1134, 'employees', 'Employees', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1135, 'classes', 'Classes', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1136, 'edit_branch', 'Edit Branch', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1137, 'show_website', 'Show Website', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1138, 'create_section', 'Create Section', '', 'Créer une nouvelle filière');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1139, 'section_list', 'Section List', '', 'List des filières');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1140, 'declined', 'Declined', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1141, 'thumb_image', 'Thumb Image', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1142, 'uploaded', 'Uploaded', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1143, 'terms_conditions', 'Terms Conditions', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1144, 'online_addmission', 'Online Addmission', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1145, 'fee', 'Fee', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1146, 'free', 'Free', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1147, 'pay', 'Pay', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1148, 'no_sms_gateway_available', 'No Sms Gateway Available', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1149, 'belongs_to', 'Belongs To', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1150, 'bs_column', 'Bs Column', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1151, 'field_order', 'Field Order', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1152, 'certificates', 'Certificates', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1153, 'language_unpublished', 'Language Unpublished', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1154, 'edit_section', 'Edit Section', '', '');
INSERT INTO `languages` (`id`, `word`, `english`, `arabic`, `french`) VALUES (1155, 'default_template', 'Default Template', '', '');


#
# TABLE STRUCTURE FOR: login_credential
#

DROP TABLE IF EXISTS `login_credential`;

CREATE TABLE `login_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` tinyint(2) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1(active) 0(deactivate)',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 1, 'superadmin@ramom.com', '$2y$10$thJe5tQhq0USn6mKcJvDVuHA/bBFQlaIrdkfwtLuvRAZDGq80EMxG', 1, 1, '2021-05-25 02:33:50', '2021-05-25 14:33:28', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (2, 2, 'faissal.elfid@gmail.com', '$2y$10$jVXTSU3ds83opCul3elgOeP1PdsfNH1s/SagahBxCjpkyBeWh7Uj6', 1, 1, '2021-12-18 13:53:42', '2021-11-04 19:42:34', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (10, 4, 'faissal', '$2y$10$G/YUVvGvVRqN1mcSuwrshez3LhXtDBSq5oUAoE.HW48t0xjK/e7JK', 3, 1, '2021-12-18 14:56:07', '2021-12-17 20:24:44', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (12, 3, 'omar', '$2y$10$MeKY/oIsuIqRJg4UHabS4eWEfWT/JVzMOx8i666KLnRw5VoDTJts6', 3, 1, '2021-12-18 13:58:56', '2021-12-18 13:09:40', NULL);


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('405');


#
# TABLE STRUCTURE FOR: online_admission
#

DROP TABLE IF EXISTS `online_admission`;

CREATE TABLE `online_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `birthday` date NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `guardian_name` varchar(255) NOT NULL,
  `guardian_relation` varchar(50) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `mother_name` varchar(255) NOT NULL,
  `grd_occupation` varchar(255) NOT NULL,
  `grd_income` varchar(25) NOT NULL,
  `grd_education` varchar(255) NOT NULL,
  `grd_email` varchar(255) NOT NULL,
  `grd_mobile_no` varchar(50) NOT NULL,
  `grd_address` varchar(255) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '1',
  `payment_status` tinyint(1) NOT NULL DEFAULT '0',
  `payment_amount` decimal(18,2) NOT NULL,
  `payment_details` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `apply_date` datetime NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `online_admission` (`id`, `first_name`, `last_name`, `gender`, `birthday`, `mobile_no`, `email`, `address`, `guardian_name`, `guardian_relation`, `father_name`, `mother_name`, `grd_occupation`, `grd_income`, `grd_education`, `grd_email`, `grd_mobile_no`, `grd_address`, `status`, `payment_status`, `payment_amount`, `payment_details`, `branch_id`, `class_id`, `section_id`, `apply_date`, `created_date`) VALUES (2, 'Faissal', 'FID', 'male', '1999-11-16', '0682484660', 'faissal.elfid@gmail.com', 'AV HASSAN 2 IMM 9 NAKHIL APT N 10 TAZA', '', '', '', '', '', '', '', '', '', '', 2, 0, '0.00', '', 1, 2, 10, '2021-11-09 20:35:41', '2021-12-14 11:58:50');


#
# TABLE STRUCTURE FOR: permission
#

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(100) NOT NULL,
  `show_view` tinyint(1) DEFAULT '1',
  `show_add` tinyint(1) DEFAULT '1',
  `show_edit` tinyint(1) DEFAULT '1',
  `show_delete` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (1, 2, 'Student', 'student', 1, 1, 1, 1, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (2, 2, 'Multiple Import', 'multiple_import', 0, 1, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (3, 2, 'Student Category', 'student_category', 1, 1, 1, 1, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (4, 2, 'Student Id Card', 'student_id_card', 1, 0, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (5, 2, 'Disable Authentication', 'student_disable_authentication', 1, 1, 0, 0, '2020-01-22 12:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (6, 4, 'Employee', 'employee', 1, 1, 1, 1, '2020-01-22 12:55:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (9, 4, 'Department', 'department', 1, 1, 1, 1, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (10, 4, 'Designation', 'designation', 1, 1, 1, 1, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (11, 4, 'Disable Authentication', 'employee_disable_authentication', 1, 1, 0, 0, '2020-01-22 18:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (12, 5, 'Salary Template', 'salary_template', 1, 1, 1, 1, '2020-01-23 06:13:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (13, 5, 'Salary Assign', 'salary_assign', 1, 1, 0, 0, '2020-01-23 06:14:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (14, 5, 'Salary Payment', 'salary_payment', 1, 1, 0, 0, '2020-01-24 07:45:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (15, 5, 'Salary Summary Report', 'salary_summary_report', 1, 0, 0, 0, '2020-03-14 18:09:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (16, 5, 'Advance Salary', 'advance_salary', 1, 1, 1, 1, '2020-01-28 19:23:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (17, 5, 'Advance Salary Manage', 'advance_salary_manage', 1, 1, 1, 1, '2020-01-25 05:57:12');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (18, 5, 'Advance Salary Request', 'advance_salary_request', 1, 1, 0, 1, '2020-01-28 18:49:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (19, 5, 'Leave Category', 'leave_category', 1, 1, 1, 1, '2020-01-29 03:46:23');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (20, 5, 'Leave Request', 'leave_request', 1, 1, 1, 1, '2020-01-30 13:06:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (21, 5, 'Leave Manage', 'leave_manage', 1, 1, 1, 1, '2020-01-29 08:27:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (22, 5, 'Award', 'award', 1, 1, 1, 1, '2020-01-31 19:49:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (23, 6, 'Classes', 'classes', 1, 1, 1, 1, '2020-02-01 19:10:00');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (24, 6, 'Section', 'section', 1, 1, 1, 1, '2020-02-01 22:06:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (25, 6, 'Assign Class Teacher', 'assign_class_teacher', 1, 1, 1, 1, '2020-02-02 08:09:22');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (26, 6, 'Subject', 'subject', 1, 1, 1, 1, '2020-02-03 05:32:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (27, 6, 'Subject Class Assign ', 'subject_class_assign', 1, 1, 1, 1, '2020-02-03 18:43:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (28, 6, 'Subject Teacher Assign', 'subject_teacher_assign', 1, 1, 0, 1, '2020-02-03 20:05:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (29, 6, 'Class Timetable', 'class_timetable', 1, 1, 1, 1, '2020-02-04 06:50:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (30, 2, 'Student Promotion', 'student_promotion', 1, 1, 0, 0, '2020-02-05 19:20:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (31, 8, 'Attachments', 'attachments', 1, 1, 1, 1, '2020-02-06 18:59:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (33, 8, 'Attachment Type', 'attachment_type', 1, 1, 1, 1, '2020-02-07 08:16:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (49, 12, 'Student Attendance', 'student_attendance', 0, 1, 0, 0, '2020-02-13 06:25:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (50, 12, 'Employee Attendance', 'employee_attendance', 0, 1, 0, 0, '2020-02-13 11:04:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (51, 12, 'Exam Attendance', 'exam_attendance', 0, 1, 0, 0, '2020-02-13 12:08:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (52, 12, 'Student Attendance Report', 'student_attendance_report', 1, 0, 0, 0, '2020-02-13 20:20:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (53, 12, 'Employee Attendance Report', 'employee_attendance_report', 1, 0, 0, 0, '2020-02-14 07:08:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (54, 12, 'Exam Attendance Report', 'exam_attendance_report', 1, 0, 0, 0, '2020-02-14 07:21:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (81, 18, 'Global Settings', 'global_settings', 1, 0, 1, 0, '2020-03-22 06:05:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (82, 18, 'Payment Settings', 'payment_settings', 1, 1, 0, 0, '2020-03-22 06:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (83, 18, 'Sms Settings', 'sms_settings', 1, 1, 1, 1, '2020-03-22 06:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (84, 18, 'Email Settings', 'email_settings', 1, 1, 1, 1, '2020-03-22 06:10:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (85, 18, 'Translations', 'translations', 1, 1, 1, 1, '2020-03-22 06:18:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (86, 18, 'Backup', 'backup', 1, 1, 1, 1, '2020-03-22 08:09:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (87, 18, 'Backup Restore', 'backup_restore', 0, 1, 0, 0, '2020-03-22 08:09:34');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (90, 18, 'School Settings', 'school_settings', 1, 0, 1, 0, '2020-03-30 18:36:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (91, 1, 'Monthly Income Vs Expense Pie Chart', 'monthly_income_vs_expense_chart', 1, 0, 0, 0, '2020-03-31 07:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (92, 1, 'Annual Student Fees Summary Chart', 'annual_student_fees_summary_chart', 1, 0, 0, 0, '2020-03-31 07:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (93, 1, 'Employee Count Widget', 'employee_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (94, 1, 'Student Count Widget', 'student_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (95, 1, 'Parent Count Widget', 'parent_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (96, 1, 'Teacher Count Widget', 'teacher_count_widget', 1, 0, 0, 0, '2020-03-31 07:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (97, 1, 'Student Quantity Pie Chart', 'student_quantity_pie_chart', 1, 0, 0, 0, '2020-03-31 08:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (98, 1, 'Weekend Attendance Inspection Chart', 'weekend_attendance_inspection_chart', 1, 0, 0, 0, '2020-03-31 08:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (99, 1, 'Admission Count Widget', 'admission_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (100, 1, 'Voucher Count Widget', 'voucher_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (101, 1, 'Transport Count Widget', 'transport_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (102, 1, 'Hostel Count Widget', 'hostel_count_widget', 1, 0, 0, 0, '2020-03-31 08:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (103, 18, 'Accounting Links', 'accounting_links', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (105, 18, 'Cron Job', 'cron_job', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (106, 18, 'Custom Field', 'custom_field', 1, 1, 1, 1, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (107, 5, 'Leave Reports', 'leave_reports', 1, 0, 0, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (108, 18, 'Live Class Config', 'live_class_config', 1, 0, 1, 0, '2020-03-31 10:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (118, 22, 'Frontend Setting', 'frontend_setting', 1, 1, 0, 0, '2019-09-11 04:24:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (119, 22, 'Frontend Menu', 'frontend_menu', 1, 1, 1, 1, '2019-09-11 05:03:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (120, 22, 'Frontend Section', 'frontend_section', 1, 1, 0, 0, '2019-09-11 05:26:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (121, 22, 'Manage Page', 'manage_page', 1, 1, 1, 1, '2019-09-11 06:54:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (122, 22, 'Frontend Slider', 'frontend_slider', 1, 1, 1, 1, '2019-09-11 07:12:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (123, 22, 'Frontend Features', 'frontend_features', 1, 1, 1, 1, '2019-09-11 07:47:51');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (124, 22, 'Frontend Testimonial', 'frontend_testimonial', 1, 1, 1, 1, '2019-09-11 07:54:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (125, 22, 'Frontend Services', 'frontend_services', 1, 1, 1, 1, '2019-09-11 08:01:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (126, 22, 'Frontend Faq', 'frontend_faq', 1, 1, 1, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (127, 2, 'Online Admission', 'online_admission', 1, 1, 0, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (128, 18, 'System Update', 'system_update', 0, 1, 0, 0, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (131, 22, 'Frontend Gallery', 'frontend_gallery', 1, 1, 1, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (132, 22, 'Frontend Gallery Category', 'frontend_gallery_category', 1, 1, 1, 1, '2019-09-11 08:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (133, 6, 'Teacher Timetable', 'teacher_timetable', 1, 0, 0, 0, '2019-09-11 08:06:16');


#
# TABLE STRUCTURE FOR: permission_modules
#

DROP TABLE IF EXISTS `permission_modules`;

CREATE TABLE `permission_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `system` tinyint(1) NOT NULL,
  `sorted` tinyint(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (1, 'Dashboard', 'dashboard', 1, 1, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (2, 'Student', 'student', 1, 3, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (4, 'Employee', 'employee', 1, 5, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (5, 'Human Resource', 'human_resource', 1, 8, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (6, 'Academic', 'academic', 1, 9, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (8, 'Attachments Book', 'attachments_book', 1, 11, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (12, 'Attendance', 'attendance', 1, 16, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (18, 'Settings', 'settings', 1, 22, '2019-05-26 23:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `created_at`) VALUES (22, 'Website', 'website', 1, 2, '2019-05-26 23:23:00');


#
# TABLE STRUCTURE FOR: reset_password
#

DROP TABLE IF EXISTS `reset_password`;

CREATE TABLE `reset_password` (
  `key` longtext NOT NULL,
  `username` varchar(100) NOT NULL,
  `login_credential_id` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `reset_password` (`key`, `username`, `login_credential_id`, `created_at`) VALUES ('f6e5e7a2ac35efc6cc6f6e66fb440604c48fc64cbbfd9162bc155d3f28e5f6a0bb8219458b29682822854397d16d0a4ff309b1bdda7a33e77738f77d25bcef94', 'faissal.elfid@gmail.com', '2', '2021-11-07 13:58:33');


#
# TABLE STRUCTURE FOR: rm_sessions
#

DROP TABLE IF EXISTS `rm_sessions`;

CREATE TABLE `rm_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('039u71vd0643tkia25c937rd4uu116tu', '::1', 1639777820, '__ci_last_regenerate|i:1639777681;name|s:7:\"faissal\";logger_photo|N;loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"10\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('046k6n30i851inlspqn55q16tm0so76b', '::1', 1639474331, '__ci_last_regenerate|i:1639474331;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('068f34e72b0bc8cca827ba221c873431d2ccb6af', '196.200.176.254', 1638434951, '__ci_last_regenerate|i:1638434951;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0c0g16dh6rq9bg03ud0cqhqdiqsst991', '::1', 1639834002, '__ci_last_regenerate|i:1639834002;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0elv29ibobnb7b4ldb8fkjik9qdhv2d8', '::1', 1639835397, '__ci_last_regenerate|i:1639835397;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0kgu31fva8k1q1t291i40ibgk4sjp07j', '::1', 1639827798, '__ci_last_regenerate|i:1639827798;name|s:8:\"Abdelati\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"0\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0la1ctm9ggg2icdfpoei2v4n6oei7g60', '::1', 1639832266, '__ci_last_regenerate|i:1639832266;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1578nmfu4ep6a3voniiq5hvseea6ldg2', '::1', 1638876186, '__ci_last_regenerate|i:1638876113;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17oac9jqids5hb4crqu7f6ondn437vqf', '::1', 1639836176, '__ci_last_regenerate|i:1639835913;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('19dc593c9fc466c504c273115dce5e7f5716401a', '102.78.1.70', 1638434645, '__ci_last_regenerate|i:1638434645;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ketds9fkg638duu6nhk9t78cashe454', '::1', 1639766493, '__ci_last_regenerate|i:1639766493;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1pjo9802icepc9g70ubh55ktsnll5pbh', '::1', 1639778770, '__ci_last_regenerate|i:1639778483;redirect_url|s:36:\"http://localhost/uca_v2/employee/add\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1tgvmskk6vv5a5b8ubheo4cgqcpsb4r3', '::1', 1638451634, '__ci_last_regenerate|i:1638451634;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2fbloi1bapp8ljg986l4gh459hk06nq9', '::1', 1638443195, '__ci_last_regenerate|i:1638443190;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2n2o3q87tnq2uevd8ds7ksjjjt481igg', '::1', 1638436938, '__ci_last_regenerate|i:1638436938;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2qa771nl3mcadreteg7m66i5ftiarnsp', '::1', 1639765407, '__ci_last_regenerate|i:1639765407;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('321buo1tt1it4kdlqkm9n29gpfa8t7ij', '::1', 1638870816, '__ci_last_regenerate|i:1638870816;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36kev4fr5r2s12rnvrt4vl9piapchsbv', '::1', 1639770375, '__ci_last_regenerate|i:1639770375;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39aj19a7gi5voccdh13qpp82o6bsbka1', '::1', 1638442832, '__ci_last_regenerate|i:1638442832;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39bfb1mqi72i9knud0t9p3lc2hc4relp', '::1', 1639834560, '__ci_last_regenerate|i:1639834560;name|s:4:\"Omar\";logger_photo|s:36:\"bff664c612a7a2c6d4749ff2c6caae0a.jpg\";loggedin_branch|s:1:\"1\";loggedin_section|s:1:\"2\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3abru71p6sjplhqdo39fia4oskjd0ajc', '::1', 1639826639, '__ci_last_regenerate|i:1639826639;name|s:7:\"faissal\";logger_photo|N;loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"10\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3jr8o08sfb37jcsrd588sh8jfp4nocdp', '::1', 1639479300, '__ci_last_regenerate|i:1639479300;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3np2ns976oa53jebh511fevstfu8drco', '::1', 1639827185, '__ci_last_regenerate|i:1639827185;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('431df698eec7577779a0943bfd627c73f745aae6', '196.200.176.254', 1638435886, '__ci_last_regenerate|i:1638435886;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('47p1epb87n70093go6cvkf5c7gkg17m1', '::1', 1638874752, '__ci_last_regenerate|i:1638874752;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('483b7k929tf82jkg9cufq2g58300pq1j', '::1', 1639835042, '__ci_last_regenerate|i:1639835042;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55ch2r4tnnrfasf5unlhbra1l1gbtuun', '::1', 1639153977, '__ci_last_regenerate|i:1639153977;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57qm0tav47vucan5ojfvv9cs6p039t1k', '::1', 1639776980, '__ci_last_regenerate|i:1639776980;redirect_url|s:36:\"http://localhost/uca_v2/employee/add\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a564o4fi63utt8r9clbf611a7l21jcc', '::1', 1639164913, '__ci_last_regenerate|i:1639164913;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5lmo698onnrjr7mao86nk53a75jklo34', '::1', 1639835900, '__ci_last_regenerate|i:1639835706;name|s:7:\"faissal\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_section|s:2:\"10\";loggedin_id|s:2:\"10\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69if3lrt3d3cupkbh7ferfdrr29d7p6m', '::1', 1639168807, '__ci_last_regenerate|i:1639168807;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ikagqj3agms6go9k25hgu4hmn90f5b8', '::1', 1639777329, '__ci_last_regenerate|i:1639777329;name|s:7:\"faissal\";logger_photo|N;loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"10\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6pg9s6jik1jt7fle0bvbt4fma8phfbnq', '::1', 1638437250, '__ci_last_regenerate|i:1638437250;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('707n85k1dm4mtp25j19lnolqt55hhi7m', '::1', 1639169348, '__ci_last_regenerate|i:1639169348;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('731oks9j131hibskber2iqsu491o3qs5', '::1', 1639778483, '__ci_last_regenerate|i:1639778483;redirect_url|s:36:\"http://localhost/uca_v2/employee/add\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('73oq4alltne5k61sct8r3cnsoi5ngabs', '::1', 1639833004, '__ci_last_regenerate|i:1639833004;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('773jl23ikr2qgt4rnrh51k4sf70j5hkq', '::1', 1639831949, '__ci_last_regenerate|i:1639831949;name|N;logger_photo|N;loggedin_branch|N;loggedin_section|N;loggedin_id|s:2:\"10\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7n0v7eqp2au8fmbjfvmqclmughkjao23', '::1', 1639832223, '__ci_last_regenerate|i:1639832223;name|s:7:\"faissal\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_section|s:2:\"10\";loggedin_id|s:2:\"10\";loggedin_userid|s:1:\"4\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7oehllj1gc9gtfa6bkc35cdcj5538eic', '::1', 1639770047, '__ci_last_regenerate|i:1639770047;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7q8rqdjk4fl6vnau93c38ossnmrkttmt', '::1', 1639162404, '__ci_last_regenerate|i:1639162404;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('803fl9ivfkhj9gueet20s3iib4qdb6fr', '::1', 1639775582, '__ci_last_regenerate|i:1639775582;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8aujo6v37r82blrjl8nf5sb8i665q7pj', '::1', 1639160976, '__ci_last_regenerate|i:1639160976;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8bgp30vl60vbp1ug4mb03cdeqsiipd70', '::1', 1639139152, '__ci_last_regenerate|i:1639139152;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f84b9bda00712a73bb0e1d97417ea15a99870df', '2.58.29.25', 1638435174, '__ci_last_regenerate|i:1638435172;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8hb9t969soud8l22ot626034rivt0cjj', '::1', 1639471779, '__ci_last_regenerate|i:1639471779;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ro31aqmbt3mmm676kj77s2jrjsan3uj', '::1', 1638443862, '__ci_last_regenerate|i:1638443862;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94tkcihmv1qh2frr3oh5f61s4msksiav', '::1', 1639148802, '__ci_last_regenerate|i:1639148802;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96omnnpo2hs418ilprcnr7sdc722ktfc', '::1', 1638440751, '__ci_last_regenerate|i:1638440751;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c2qttf6nv5pct2752v75ei11jtdfood', '::1', 1639479635, '__ci_last_regenerate|i:1639479635;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c47jnfl7g85lgd9q6la39oqht01ak15', '::1', 1639831562, '__ci_last_regenerate|i:1639831562;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9gvgmgnr3l7sa4sr01mgq1bfpcps0oh9', '::1', 1639776250, '__ci_last_regenerate|i:1639776250;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ot9c2ltiba704dsgmk0g5309qqujl7h', '::1', 1639834481, '__ci_last_regenerate|i:1639834481;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4idbjdjukp0n2pt7onh71dt82d4f187', '::1', 1639152154, '__ci_last_regenerate|i:1639152154;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a63j7ghm74vje1iv2oe6uk2lkh99d8e0', '::1', 1639768036, '__ci_last_regenerate|i:1639768036;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa9d68a2d00b55473eee107ad4eeddd30b10640b', '196.200.176.254', 1638435886, '__ci_last_regenerate|i:1638435886;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été enregistrées avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ajqcrb4o848s5fmnhto5ce9phk9r60lu', '::1', 1639162770, '__ci_last_regenerate|i:1639162770;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('asn327hjuukst6djop20u0gfe7vavcgp', '::1', 1638442477, '__ci_last_regenerate|i:1638442477;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aumhpp80p24qlc7oc5j7o5hv7e42qihs', '::1', 1639156620, '__ci_last_regenerate|i:1639156620;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b0b5f0a222225e354b86ab817dfb04ce02312b3c', '196.200.176.254', 1638435269, '__ci_last_regenerate|i:1638435269;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été enregistrées avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b46k2rd4c4antopl6cg3425cva0nfi99', '::1', 1638443549, '__ci_last_regenerate|i:1638443549;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b70hdvre2cqghs4nqditip1o4toc6uaa', '::1', 1639475740, '__ci_last_regenerate|i:1639475740;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bnfhqn5uflk3hgu4kerpkld9qb3koqp2', '::1', 1639473391, '__ci_last_regenerate|i:1639473391;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bt37o9duq3uus7jhdvttso6ue0mfd5r3', '::1', 1639835913, '__ci_last_regenerate|i:1639835913;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bvj2t70lkjl2v2d0pk8383u7b9t63i49', '::1', 1639150806, '__ci_last_regenerate|i:1639150806;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c8j060vmnv5g6imd40l3vbbrfgbrb7a2', '::1', 1638869611, '__ci_last_regenerate|i:1638869611;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c929ta434gv8khevflo362t6oasakjul', '::1', 1639834235, '__ci_last_regenerate|i:1639834235;name|s:4:\"Omar\";logger_photo|s:36:\"bff664c612a7a2c6d4749ff2c6caae0a.jpg\";loggedin_branch|s:1:\"1\";loggedin_section|s:1:\"2\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c9fm90nv70qh91e3dh5v0hsd7a9sefth', '::1', 1639764666, '__ci_last_regenerate|i:1639764666;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca3lokh5ljtg43ok10gvmp991h5i7n1e', '::1', 1639768748, '__ci_last_regenerate|i:1639768748;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('carurkn2ric9q4d81924t7l0q7f6ddgd', '::1', 1639828644, '__ci_last_regenerate|i:1639828644;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cjmj98jmoiiltl0fqaoqk9jlqt1i5a2k', '::1', 1639765069, '__ci_last_regenerate|i:1639765069;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d244v7ah59b0ielv52ktj4bhe813arnu', '::1', 1639150451, '__ci_last_regenerate|i:1639150451;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4ebe97534edc98f36282f2b5de5760b1cdce4bd', '196.200.176.254', 1638434267, '__ci_last_regenerate|i:1638434267;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6g2kf0f1n8g6glm4r7t6l1p4ss5ku9m', '::1', 1638876113, '__ci_last_regenerate|i:1638876113;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7q6paicu0m807v392a7mlsu07ncd6dp', '::1', 1639833888, '__ci_last_regenerate|i:1639833888;name|s:4:\"Omar\";logger_photo|s:36:\"bff664c612a7a2c6d4749ff2c6caae0a.jpg\";loggedin_branch|s:1:\"1\";loggedin_section|s:1:\"2\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e68nub216p0f19qva1ar1bsc7s22gjk3', '::1', 1639827497, '__ci_last_regenerate|i:1639827497;name|s:8:\"Abdelati\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"0\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eehpqhljs363nga7q5imflhmrptoo64d', '::1', 1639829789, '__ci_last_regenerate|i:1639829789;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('efa1ljhbkaiiuspu5rsesa7rnti5lm8i', '::1', 1639473999, '__ci_last_regenerate|i:1639473999;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ejn0iouvmeji1jnqrgm4csqncr3694rk', '::1', 1638875120, '__ci_last_regenerate|i:1638875120;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ekc9ii0l4rp5esgtgoe0i0ciacttp66j', '::1', 1639828500, '__ci_last_regenerate|i:1639828500;name|s:8:\"Abdelati\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"0\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f80jrut914erlnh446rbbu4rdumpc0ti', '::1', 1639472605, '__ci_last_regenerate|i:1639472605;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa1m8jqb23o1g5k9r954ojq9qr5hntkr', '::1', 1639149444, '__ci_last_regenerate|i:1639149444;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été enregistrées avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fg60t6lb8gltar26chkrhctecuisvf3s', '::1', 1639832573, '__ci_last_regenerate|i:1639832573;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_section|s:1:\"0\";loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fgf35eiv1qkodt9ao65dom5so1b3ch47', '::1', 1639161303, '__ci_last_regenerate|i:1639161303;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fhs90nuotnbe1sjgdlj0omitbg4r6heb', '::1', 1639775105, '__ci_last_regenerate|i:1639775105;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fp4i947i1papjamdhuup6dgck5c2p8cb', '::1', 1639828127, '__ci_last_regenerate|i:1639828127;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g2kjli60uuuqr563ck30pvc56plsrss8', '::1', 1639835706, '__ci_last_regenerate|i:1639835706;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g44gfmkq0klfn3jr396hpphs5obaim7o', '::1', 1639478518, '__ci_last_regenerate|i:1639478518;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g99hurttrk4tc850rnmrlbsn5gmh2ar7', '::1', 1639473029, '__ci_last_regenerate|i:1639473029;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gorqrk53rgaigb7fdi8rqp54377algjb', '::1', 1639138519, '__ci_last_regenerate|i:1639138519;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gqc1itn83kosdgllvsekcm857h158id6', '::1', 1638869916, '__ci_last_regenerate|i:1638869916;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h5cke0g05dknprrrk445and3ch6v4kdv', '::1', 1639156928, '__ci_last_regenerate|i:1639156928;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h7ct4mrig7aqt5q07kvtvbqncls3ruvs', '192.168.43.181', 1639477669, '__ci_last_regenerate|i:1639477668;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hddnmd59ej7h9gof6j91oiqfg0k69qpg', '::1', 1639152594, '__ci_last_regenerate|i:1639152594;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i35n7djop7pk3pu0aroqbr7upvn0uuj5', '::1', 1638451634, '__ci_last_regenerate|i:1638451634;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iae1frrucvobl2nqbakin0knm5eqc6ep', '::1', 1639164181, '__ci_last_regenerate|i:1639164181;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('itp4h22j7e5cqqel9nkdv2qg2lo4c2c5', '::1', 1639140238, '__ci_last_regenerate|i:1639140238;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été enregistrées avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j630bruei5iv70fupi2sbskm2pfjc7j6', '::1', 1639474996, '__ci_last_regenerate|i:1639474996;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j6n76g8b29rpi2fs9pjjvntngf3b4h9t', '::1', 1638441391, '__ci_last_regenerate|i:1638441391;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jja63vnvcp1fnhhgnrofa73lna350nbb', '::1', 1639163585, '__ci_last_regenerate|i:1639163585;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jr6vu9aplvlugkmk3s62hg396hpmdq9e', '::1', 1639151848, '__ci_last_regenerate|i:1639151848;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kcg8s2phdemuc2m3jtmkd199ho0aa5a9', '::1', 1639155728, '__ci_last_regenerate|i:1639155728;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('khpphb0ueetbh0iljn3onhhataq9888d', '::1', 1639768445, '__ci_last_regenerate|i:1639768445;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kmlcoum8q0f4uon4sji7jh45apr0man4', '::1', 1639139923, '__ci_last_regenerate|i:1639139923;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('knp73l0reinn7ve3uk0bkmk7mksa9bvq', '::1', 1639149775, '__ci_last_regenerate|i:1639149775;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été enregistrées avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('knpvo8krif9dccrge0fjcqmvvnip81l8', '::1', 1639161739, '__ci_last_regenerate|i:1639161739;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kscuovo6te92u2dmpvhicoapghbjbkie', '::1', 1639479875, '__ci_last_regenerate|i:1639479635;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ksfd6ik7d5m63gemv6ljjpao1ov7ol0g', '::1', 1639829854, '__ci_last_regenerate|i:1639829854;name|s:8:\"Abdelati\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"0\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l2p8pqtup51oie049amdsdjfrkcoj43d', '::1', 1638437902, '__ci_last_regenerate|i:1638437902;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l6ap21ulnh27gsr253etolbbit3iu5ie', '::1', 1639767648, '__ci_last_regenerate|i:1639767648;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('le6st2nu5jpdcnme3dgklfl1ipeql0it', '::1', 1639769746, '__ci_last_regenerate|i:1639769746;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lfapbrm79dk47kfbc1p4b63dfi2omdi1', '::1', 1639473694, '__ci_last_regenerate|i:1639473694;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lg7rkd546mre18m1vqcf3djvrags76br', '::1', 1638444736, '__ci_last_regenerate|i:1638444736;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lgucj6i0u7rqftm0pi9g7ub7b3b3g8jk', '::1', 1638875432, '__ci_last_regenerate|i:1638875432;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lprgnqfqckbcongp5l0bjc28qm9sf0fj', '::1', 1639472236, '__ci_last_regenerate|i:1639472236;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lqbtp3ar4od9piu2ij7mn4oe3bfp3c6q', '::1', 1639167929, '__ci_last_regenerate|i:1639167929;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lqfghekupkulh6tu599fg2ifctln3qk6', '::1', 1639766097, '__ci_last_regenerate|i:1639766097;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lqq8mru6j0muranhteo920gkn1osp9p3', '::1', 1639776554, '__ci_last_regenerate|i:1639776554;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mhen8pfdqd4grc04qthfr5qn2ou64e86', '::1', 1639829538, '__ci_last_regenerate|i:1639829538;name|s:8:\"Abdelati\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"0\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mlb57b6l4jbbl1up9q0d8ei64ov6m886', '::1', 1639474673, '__ci_last_regenerate|i:1639474673;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('np596dt34idkcjdi4sgelsd4ebef2pb8', '::1', 1639471227, '__ci_last_regenerate|i:1639471227;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('obfqbnajm8lbtu7o96dimemidk2of0lm', '::1', 1639169348, '__ci_last_regenerate|i:1639169348;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('og2sl3c8i8k29ps7qdvmlpjvu21p2r4g', '::1', 1639149136, '__ci_last_regenerate|i:1639149136;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oijmo2sf815skth6vjrqeonat5pms09d', '::1', 1639829380, '__ci_last_regenerate|i:1639829380;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ors8un8hu1k576ivfkq1kineddij0sdi', '::1', 1639832847, '__ci_last_regenerate|i:1639832847;name|s:4:\"Omar\";logger_photo|s:36:\"bff664c612a7a2c6d4749ff2c6caae0a.jpg\";loggedin_branch|s:1:\"1\";loggedin_section|s:1:\"2\";loggedin_id|s:2:\"12\";loggedin_userid|s:1:\"3\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('osgldn79eq6c6e0l4mhea0e57gl6qp0e', '::1', 1638870373, '__ci_last_regenerate|i:1638870373;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pis6k2ifo1mdrri7e6i1t6sd3o1g947m', '::1', 1639477436, '__ci_last_regenerate|i:1639477436;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('puboe3kjfmk0ihfk7t87bjd3abuor2l7', '::1', 1639775885, '__ci_last_regenerate|i:1639775885;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été enregistrées avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pvip4e3hdrqi0l1o7h6m01kdj0q3h2rc', '::1', 1639139488, '__ci_last_regenerate|i:1639139488;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q0qnqsrrfq3hq1d5441nkt3ffto1bg28', '::1', 1639826979, '__ci_last_regenerate|i:1639826979;name|s:7:\"faissal\";logger_photo|N;loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"10\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qb9983r62d1eo6t18fg2p87bldsaa7ae', '::1', 1639777922, '__ci_last_regenerate|i:1639777922;redirect_url|s:36:\"http://localhost/uca_v2/employee/add\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qf21qftgum98vebn8ipnle0h7ji8oq8l', '::1', 1639830237, '__ci_last_regenerate|i:1639830237;name|s:8:\"Abdelati\";logger_photo|s:11:\"defualt.png\";loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"11\";loggedin_userid|s:1:\"0\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qmq576lel8icb6dtuqf2hpsmuu9g7sum', '::1', 1638437592, '__ci_last_regenerate|i:1638437592;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qnq0aub01bb5is1medb7uumvlgoaljno', '::1', 1638444177, '__ci_last_regenerate|i:1638444177;redirect_url|s:33:\"http://localhost/uca_v2/dashboard\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r9kt6rnu25a5acchh36qv5sinc9k3qq0', '::1', 1639163280, '__ci_last_regenerate|i:1639163280;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s1i5jshavqnfhak2v5kislbdtppog24a', '::1', 1639151539, '__ci_last_regenerate|i:1639151539;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s4g05q3qgqj74de1rtlb9p5tgckrbr57', '::1', 1639156255, '__ci_last_regenerate|i:1639156255;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sld7eba846fq7tq3ri3dgnhilqj0fjf7', '::1', 1639777580, '__ci_last_regenerate|i:1639777580;redirect_url|s:36:\"http://localhost/uca_v2/employee/add\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('slpapif6ng22dfts3rnh798daflro5o5', '::1', 1639150142, '__ci_last_regenerate|i:1639150142;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sn13skjk33roupukb7i7mu4jrseplpfo', '::1', 1638441436, '__ci_last_regenerate|i:1638441391;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('snuhjvil6n0jsiulsoj82qf49j4sfbdo', '::1', 1639140255, '__ci_last_regenerate|i:1639140238;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('toiut2alesurkvrn5acs4qf4mlb3se07', '::1', 1638873354, '__ci_last_regenerate|i:1638873354;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tp01iqh8pcbch75sifgmi6007i3u50nv', '::1', 1638875796, '__ci_last_regenerate|i:1638875796;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tqpkpoge875ls1bskqir4jak0ebanh5n', '::1', 1639764145, '__ci_last_regenerate|i:1639764145;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u1kfqesv779eemvgegsfuvf8maer2nq2', '::1', 1639472703, '__ci_last_regenerate|i:1639472699;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uc6f30fibq86aq6pfvvvo89jp9pmd8g7', '::1', 1639777681, '__ci_last_regenerate|i:1639777681;name|s:7:\"faissal\";logger_photo|N;loggedin_branch|s:1:\"1\";loggedin_id|s:2:\"10\";loggedin_userid|s:2:\"10\";loggedin_role_id|s:1:\"3\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('udluqdii4c3iugmneqf90pg5crvum5sc', '::1', 1639151152, '__ci_last_regenerate|i:1639151152;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uffa5ivhbtktpn6jbceskanuhdf5rpuv', '::1', 1639769189, '__ci_last_regenerate|i:1639769189;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v1if43nbmf0epn0p558h0qj5s9i1hov7', '::1', 1638441068, '__ci_last_regenerate|i:1638441068;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;alert-message-success|s:53:\"Les informations ont été mises à jour avec succès\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v29q66mlj117mnte61hckreo5rpbf2uf', '::1', 1639477941, '__ci_last_regenerate|i:1639477941;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v2ift2difoudp6u1us0v3rf63engtec1', '::1', 1639138208, '__ci_last_regenerate|i:1639138208;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"1\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v4gkr91msptjetdp0p7uloj8irfs9rbh', '::1', 1639475378, '__ci_last_regenerate|i:1639475378;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7atl7ku65bd6ho0d52rcsrkpefbfj4m', '::1', 1639826307, '__ci_last_regenerate|i:1639826307;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v94qalmv6uuqmd7bg6la2eg3rucsctu7', '::1', 1639168403, '__ci_last_regenerate|i:1639168403;redirect_url|s:47:\"http://localhost/uca_v2/sessions/set_academic/3\";name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ve75o4a5uo86p1j3p3fqoco8hughvt4r', '::1', 1638874403, '__ci_last_regenerate|i:1638874403;name|s:7:\"Faissal\";logger_photo|N;loggedin_branch|N;loggedin_id|s:1:\"2\";loggedin_userid|s:1:\"2\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:6:\"french\";set_session_id|s:1:\"3\";loggedin|b:1;');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `is_system` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (1, 'Super Admin', 'superadmin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (2, 'Admin', 'admin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (3, 'Teacher', 'teacher', '1');


#
# TABLE STRUCTURE FOR: schoolyear
#

DROP TABLE IF EXISTS `schoolyear`;

CREATE TABLE `schoolyear` (
  `id` int(11) NOT NULL,
  `school_year` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (1, '2019-2020', 1, '2020-02-25 20:35:41', '2020-02-26 16:54:49');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (3, '2020-2021', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (4, '2021-2022', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (5, '2022-2023', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (6, '2023-2024', 1, '2020-02-25 20:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (7, '2024-2025', 1, '2020-02-25 20:35:41', '2020-02-26 01:20:04');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (9, '2025-2026', 1, '2020-02-26 08:00:10', '2020-02-26 13:00:24');


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `capacity` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (2, 'Finance , Banque et Assurance mode hybrid', 'fst', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (3, 'Tutorat de langues étrangéres', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (4, 'Transport et logistique', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (5, 'Community et revenue management touristique', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (6, 'Préparation à l\'agrégation', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (7, 'Accessibilité physique des personnes en situation d\'handicap', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (8, 'Marketing digital', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (9, 'Pédagogie unversitaire', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (10, 'Actuariat et risk management', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (11, 'Management des ressources Humaines', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (12, 'Stratégie et Marketing des services', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (13, 'Ingénierie Génie Civil Environnement et qualité', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (14, 'Management Qualité Hygiène Sécurité et Environnement', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (15, 'Data sciences appliquées en management et economie', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (16, 'logistique de distrubition et supply chain managemenet', '', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (17, 'DIPLÔME UNIVERSITAIRE MÉDECINE', '', 1);


#
# TABLE STRUCTURE FOR: sections_allocation
#

DROP TABLE IF EXISTS `sections_allocation`;

CREATE TABLE `sections_allocation` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (13, 2, 10);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (14, 2, 11);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (15, 2, 12);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (16, 2, 13);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (17, 2, 14);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (18, 3, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (19, 3, 4);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (20, 3, 5);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (21, 3, 6);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (22, 3, 7);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (23, 3, 8);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (24, 3, 9);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (25, 1, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (26, 1, 15);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (27, 1, 16);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (28, 4, 17);


#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `present_address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `sex`, `present_address`, `mobileno`, `email`, `branch_id`, `photo`, `created_at`, `updated_at`) VALUES (1, '98b09e6', 'superadmin', 0, '', '', '', 'superadmin@ramom.com', NULL, NULL, '2021-05-25 14:33:28', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `sex`, `present_address`, `mobileno`, `email`, `branch_id`, `photo`, `created_at`, `updated_at`) VALUES (2, '5254520', 'Faissal', 0, '', '', '', 'faissal.elfid@gmail.com', NULL, NULL, '2021-11-04 19:42:34', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `sex`, `present_address`, `mobileno`, `email`, `branch_id`, `photo`, `created_at`, `updated_at`) VALUES (3, '3508303', 'Omar', 2, 'male', 'Marrakech, Sidi Abad', '062845960', 'omar@gmail.com', 1, 'bff664c612a7a2c6d4749ff2c6caae0a.jpg', '2021-12-18 13:09:40', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `sex`, `present_address`, `mobileno`, `email`, `branch_id`, `photo`, `created_at`, `updated_at`) VALUES (4, '782074a', 'faissal', 10, 'male', 'Marrakech, Sidi Abad', '062845960', 'faissal@gmail.com', 1, 'defualt.png', '2021-12-18 13:11:24', NULL);


#
# TABLE STRUCTURE FOR: staff_privileges
#

DROP TABLE IF EXISTS `staff_privileges`;

CREATE TABLE `staff_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_add` tinyint(1) NOT NULL,
  `is_edit` tinyint(1) NOT NULL,
  `is_view` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=722 DEFAULT CHARSET=utf8;

INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (1, 3, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (88, 2, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (89, 2, 2, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (90, 2, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (91, 2, 4, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (92, 2, 5, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (93, 2, 30, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (94, 2, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (95, 2, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (96, 2, 6, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (97, 2, 9, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (98, 2, 10, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (99, 2, 11, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (100, 2, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (101, 2, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (102, 2, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (103, 2, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (104, 2, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (105, 2, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (107, 2, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (108, 2, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (109, 2, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (110, 2, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (111, 2, 23, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (112, 2, 24, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (113, 2, 25, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (114, 2, 26, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (115, 2, 27, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (116, 2, 28, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (117, 2, 29, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (118, 2, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (119, 2, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (120, 2, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (121, 2, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (122, 2, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (123, 2, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (124, 2, 37, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (125, 2, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (126, 2, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (127, 2, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (128, 2, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (129, 2, 79, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (130, 2, 40, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (131, 2, 41, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (132, 2, 42, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (133, 2, 43, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (134, 2, 44, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (135, 2, 45, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (136, 2, 46, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (137, 2, 47, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (138, 2, 48, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (139, 2, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (140, 2, 50, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (141, 2, 51, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (142, 2, 52, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (143, 2, 53, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (144, 2, 54, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (145, 2, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (146, 2, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (147, 2, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (148, 2, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (149, 2, 59, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (150, 2, 60, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (151, 2, 61, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (152, 2, 62, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (153, 2, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (154, 2, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (155, 2, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (156, 2, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (157, 2, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (158, 2, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (159, 2, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (160, 2, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (161, 2, 76, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (162, 2, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (163, 2, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (164, 2, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (165, 2, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (166, 2, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (167, 2, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (168, 2, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (169, 2, 82, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (170, 2, 83, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (171, 2, 84, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (172, 2, 85, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (173, 2, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (174, 2, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (175, 7, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (176, 7, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (177, 7, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (178, 7, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (179, 7, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (180, 7, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (181, 7, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (182, 7, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (183, 7, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (184, 7, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (185, 7, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (186, 7, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (187, 7, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (188, 7, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (189, 7, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (190, 7, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (191, 7, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (192, 7, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (194, 7, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (195, 7, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (196, 7, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (197, 7, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (198, 7, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (199, 7, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (200, 7, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (201, 7, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (202, 7, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (203, 7, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (204, 7, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (205, 7, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (206, 7, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (207, 7, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (208, 7, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (209, 7, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (210, 7, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (211, 7, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (212, 7, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (213, 7, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (214, 7, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (215, 7, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (216, 7, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (217, 7, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (218, 7, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (219, 7, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (220, 7, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (221, 7, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (222, 7, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (223, 7, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (224, 7, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (225, 7, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (226, 7, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (227, 7, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (228, 7, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (229, 7, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (230, 7, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (231, 7, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (232, 7, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (233, 7, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (234, 7, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (235, 7, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (236, 7, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (237, 7, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (238, 7, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (239, 7, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (240, 7, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (241, 7, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (242, 7, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (243, 7, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (244, 7, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (245, 7, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (246, 7, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (247, 7, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (248, 7, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (249, 7, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (250, 7, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (251, 7, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (252, 7, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (253, 7, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (254, 7, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (255, 7, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (256, 7, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (257, 7, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (258, 7, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (259, 7, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (260, 7, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (261, 7, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (262, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (263, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (264, 89, 89, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (265, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (266, 2, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (267, 2, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (268, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (269, 2, 90, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (270, 91, 91, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (271, 92, 92, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (272, 2, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (273, 2, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (274, 93, 93, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (275, 94, 94, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (276, 95, 95, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (277, 96, 96, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (278, 2, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (279, 2, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (280, 2, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (281, 2, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (282, 97, 97, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (283, 98, 98, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (284, 2, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (285, 2, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (286, 99, 99, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (287, 100, 100, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (288, 101, 101, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (289, 102, 102, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (290, 2, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (291, 2, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (292, 2, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (293, 2, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (294, 103, 103, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (295, 2, 103, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (312, 4, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (313, 4, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (314, 4, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (315, 4, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (316, 4, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (317, 4, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (318, 4, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (319, 4, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (320, 4, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (321, 4, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (322, 4, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (323, 4, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (324, 4, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (325, 4, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (326, 4, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (327, 4, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (328, 4, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (329, 4, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (330, 4, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (331, 4, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (332, 4, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (333, 4, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (334, 4, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (335, 4, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (336, 4, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (337, 4, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (338, 4, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (339, 4, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (340, 4, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (341, 4, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (343, 4, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (344, 4, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (345, 4, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (346, 4, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (347, 4, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (348, 4, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (349, 4, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (350, 4, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (351, 4, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (352, 4, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (353, 4, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (354, 4, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (355, 4, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (356, 4, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (357, 4, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (358, 4, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (359, 4, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (360, 4, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (361, 4, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (362, 4, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (363, 4, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (364, 4, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (365, 4, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (366, 4, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (367, 4, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (368, 4, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (369, 4, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (370, 4, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (371, 4, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (372, 4, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (373, 4, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (374, 4, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (375, 4, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (376, 4, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (377, 4, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (378, 4, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (379, 4, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (380, 4, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (381, 4, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (382, 4, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (383, 4, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (384, 4, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (385, 4, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (386, 4, 58, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (387, 4, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (388, 4, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (389, 4, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (390, 4, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (391, 4, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (392, 4, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (393, 4, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (394, 4, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (395, 4, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (396, 4, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (397, 4, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (398, 4, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (399, 4, 76, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (400, 4, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (401, 4, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (402, 4, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (403, 4, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (404, 4, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (405, 4, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (406, 4, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (407, 4, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (408, 4, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (409, 4, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (410, 4, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (411, 4, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (412, 4, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (413, 4, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (414, 4, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (415, 5, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (416, 5, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (417, 5, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (418, 5, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (419, 5, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (420, 5, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (421, 5, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (422, 5, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (423, 5, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (424, 5, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (425, 5, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (426, 5, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (427, 5, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (428, 5, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (429, 5, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (430, 5, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (431, 5, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (432, 5, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (433, 5, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (434, 5, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (435, 5, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (436, 5, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (437, 5, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (438, 5, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (439, 5, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (440, 5, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (441, 5, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (442, 5, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (443, 5, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (444, 5, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (446, 5, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (447, 5, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (448, 5, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (449, 5, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (450, 5, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (451, 5, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (452, 5, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (453, 5, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (454, 5, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (455, 5, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (456, 5, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (457, 5, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (458, 5, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (459, 5, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (460, 5, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (461, 5, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (462, 5, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (463, 5, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (464, 5, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (465, 5, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (466, 5, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (467, 5, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (468, 5, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (469, 5, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (470, 5, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (471, 5, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (472, 5, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (473, 5, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (474, 5, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (475, 5, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (476, 5, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (477, 5, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (478, 5, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (479, 5, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (480, 5, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (481, 5, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (482, 5, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (483, 5, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (484, 5, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (485, 5, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (486, 5, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (487, 5, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (488, 5, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (489, 5, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (490, 5, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (491, 5, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (492, 5, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (493, 5, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (494, 5, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (495, 5, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (496, 5, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (497, 5, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (498, 5, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (499, 5, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (500, 5, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (501, 5, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (502, 5, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (503, 5, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (504, 5, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (505, 5, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (506, 5, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (507, 5, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (508, 5, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (509, 5, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (510, 5, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (511, 5, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (512, 5, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (513, 5, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (514, 5, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (515, 5, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (516, 5, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (517, 5, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (518, 104, 104, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (519, 2, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (520, 4, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (521, 2, 18, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (522, 2, 105, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (523, 2, 106, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (524, 2, 107, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (525, 2, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (526, 2, 108, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (527, 3, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (528, 3, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (529, 3, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (530, 3, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (531, 3, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (532, 3, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (533, 3, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (534, 2, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (535, 2, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (536, 2, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (537, 2, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (538, 2, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (539, 2, 115, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (540, 2, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (541, 2, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (550, 2, 127, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (551, 2, 118, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (552, 2, 119, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (553, 2, 120, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (554, 2, 121, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (555, 2, 122, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (556, 2, 123, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (557, 2, 124, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (558, 2, 125, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (559, 2, 126, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (560, 3, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (561, 3, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (562, 3, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (563, 3, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (564, 3, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (565, 3, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (566, 3, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (567, 3, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (568, 3, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (569, 3, 127, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (570, 3, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (571, 2, 129, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (572, 2, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (573, 2, 131, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (574, 2, 132, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (575, 2, 130, 0, 0, 0, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (576, 4, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (577, 4, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (578, 4, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (579, 4, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (580, 4, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (581, 4, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (582, 4, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (583, 4, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (584, 4, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (585, 4, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (586, 4, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (587, 4, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (588, 4, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (589, 4, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (590, 4, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (591, 4, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (592, 4, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (593, 4, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (594, 4, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (595, 4, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (596, 4, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (597, 4, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (598, 4, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (599, 4, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (600, 4, 130, 0, 0, 0, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (601, 4, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (602, 4, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (603, 4, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (604, 4, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (605, 2, 131, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (606, 2, 132, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (607, 2, 133, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (608, 3, 133, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (609, 3, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (610, 3, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (611, 3, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (612, 3, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (613, 3, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (614, 3, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (615, 3, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (616, 3, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (617, 3, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (618, 3, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (619, 3, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (620, 3, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (621, 3, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (622, 3, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (623, 3, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (624, 3, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (625, 3, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (626, 3, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (627, 3, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (628, 3, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (629, 3, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (630, 3, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (631, 3, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (632, 3, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (633, 3, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (634, 3, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (635, 3, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (636, 3, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (637, 3, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (638, 3, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (639, 3, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (640, 3, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (641, 3, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (642, 3, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (643, 3, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (644, 3, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (645, 3, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (646, 3, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (647, 3, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (648, 3, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (649, 3, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (650, 3, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (651, 3, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (652, 3, 23, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (653, 3, 24, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (654, 3, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (655, 3, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (656, 3, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (657, 3, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (658, 3, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (659, 3, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (660, 3, 31, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (661, 3, 33, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (662, 3, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (663, 3, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (664, 3, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (665, 3, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (666, 3, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (667, 3, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (668, 3, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (669, 3, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (670, 3, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (671, 3, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (672, 3, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (673, 3, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (674, 3, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (675, 3, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (676, 3, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (677, 3, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (678, 3, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (679, 3, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (680, 3, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (681, 3, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (682, 3, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (683, 3, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (684, 3, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (685, 3, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (686, 3, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (687, 3, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (688, 3, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (689, 3, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (690, 3, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (691, 3, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (692, 3, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (693, 3, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (694, 3, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (695, 3, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (696, 3, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (697, 3, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (698, 3, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (699, 3, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (700, 3, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (701, 3, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (702, 3, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (703, 3, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (704, 3, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (705, 3, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (706, 3, 130, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (707, 3, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (708, 3, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (709, 3, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (710, 3, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (711, 3, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (712, 3, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (713, 3, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (714, 3, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (715, 3, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (716, 3, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (717, 3, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (718, 3, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (719, 3, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (720, 3, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (721, 3, 103, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: theme_settings
#

DROP TABLE IF EXISTS `theme_settings`;

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL,
  `border_mode` varchar(200) NOT NULL,
  `dark_skin` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `theme_settings` (`id`, `border_mode`, `dark_skin`, `created_at`, `updated_at`) VALUES (1, 'false', 'false', '2018-10-23 17:59:38', '2020-05-10 14:08:47');


